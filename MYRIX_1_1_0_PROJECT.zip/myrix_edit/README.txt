MYRIX — Android WebView video editor source project

AUDITED EFFECTS UPDATE
- Catalog expanded to 66 effect keys, grouped into JJ / Animation, Light / Texture, Cinematic / Color, and Layer / Detail.
- New effects include Flash, Strobe, Zoom Pulse, Spin, Motion Blur / Trail, Zoom Blur, Light Leak, Lens Flare, Film Grain, Scanlines, Halftone, Duotone, Bleach Bypass, Pastel, Cyberpunk, Sunset, Rainbow Shift, Mirror, Outline, Emboss, Posterize, VHS Tracking, Flicker, Bloom, Directional Blur, Color Tint, and Edge Pop.
- Each effect has on/off state and per-effect intensity; effects with supported parameters expose their own controls. Animated effects expose speed controls. Effect settings stay in the project's existing serialized `fx` data and legacy project settings are normalized with new effects off by default.
- Preview and Canvas export paths both render the added effects. Some effects (for example RGB separation, Posterize, Motion Blur, and some color looks) are practical CSS/Canvas approximations, not pixel-identical native/Alight Motion shader implementations. Performance and exact visual matching depend on the browser/device.

SOURCE VALIDATION
Run from the repository root:
  python3 scripts/validate-project.py
  node scripts/test-effects.cjs

The build workflow runs these source checks before attempting the Android debug APK build. The checks cover inline JavaScript syntax, duplicate HTML IDs, local asset references, Android XML well-formedness, effect-key/schema/catalog consistency, filter/animation output sanity, bounds, and legacy effect-data normalization.

BUILD APK USING GITHUB FROM AN ANDROID PHONE
1. Extract this ZIP on your phone.
2. In GitHub, create a new repository (e.g. MYRIX), preferably private if you don't want to publish the source.
3. Upload the CONTENTS of the project folder to the repository root. Make sure `.github/workflows/build-apk.yml` is uploaded too. The `scripts` folder must remain at the repository root because the workflow runs its validation scripts.
4. Open the repository's Actions tab and select "Build MYRIX APK". If asked, enable GitHub Actions.
5. Tap "Run workflow" or push to main/master to trigger automatically.
6. Open the successful workflow run, scroll to Artifacts, and download "MYRIX-debug-APK". Extract it; the file is `app-debug.apk`.
7. Open the APK on your phone and allow installation from that source if Android asks.

IMPORTANT
- This is a source project, not a prebuilt APK.
- The workflow builds a DEBUG APK, not a Play Store release. A Play Store release needs signing and separate release preparation.
- The source checks pass in the development environment, but they are static/logic tests; an actual Gradle build, Android WebView interaction test, and device-specific export test still need to run via GitHub Actions and on the target phone.
- Internet may be needed for CDN-backed MP4 export features.
- The editor is bundled in `app/src/main/assets/index.html`; its logo is `app/src/main/assets/logo.png`.

BEAT EDITOR FIX
- Beat controls are exposed on window because the editor is wrapped in an IIFE; this is required for inline HTML onclick handlers in WebView/Acode.
- The project validator now checks all five Beat action exports to prevent regression.
- Run `python3 scripts/validate-project.py` and `node scripts/test-effects.cjs` before uploading.


Pembaruan editor gerak: ruler timeline per detik, grid layer, auto-follow playhead, perbaikan drag objek berdasarkan zoom, mode tangan untuk memindahkan kanvas, dan preset animasi yang mengikuti playhead. Lihat MOTION_TIMELINE_CHANGELOG.txt. Jalankan `python3 scripts/validate-project.py` dan tiga test Node di folder scripts sebelum build.

TIMELINE FIX (2026-10-15)
- Playback controls and Beat settings have their own fixed dock.
- Horizontal scroll is isolated to the timeline ruler and layer tracks.
- Playback auto-follow scrolls only the layer/timeline viewport, not the Beat controls.
- Run the extra regression check with: node scripts/test-fixed-beat-controls.cjs


Versi 1.1.0 (versionCode 2):
- Menambahkan crop foto dengan preset rasio Asli, 1:1, 4:5, 9:16, 16:9, dan 4:3. Crop tersimpan dalam data proyek dan ikut dirender saat ekspor.
- Memperjelas kontrol pemotongan klip video/audio di tab Media (Set Awal, Set Akhir, Potong di Playhead).
- Menambahkan tes regresi crop, data proyek, dan versi aplikasi.
- Pemeriksaan otomatis bukan pengganti uji manual ekspor video di HP.
