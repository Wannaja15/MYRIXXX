#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(__dirname, '..', 'app', 'build.gradle'), 'utf8');

assert.match(html, /application-version" content="1\.1\.0/);
assert.match(html, /v1\.1\.0/);
assert.match(gradle, /versionCode\s+2/);
assert.match(gradle, /versionName\s+'1\.1\.0'/);
assert.match(html, /id="photoCropTools"/);
for (const ratio of ['original','1:1','4:5','9:16','16:9','4:3']) {
  assert.ok(html.includes(`cropSelectedPhoto('${ratio}')`), `crop preset ${ratio} missing`);
}
assert.match(html, /window\.cropSelectedPhoto=cropSelectedPhoto/);
assert.match(html, /crop:normalizeCrop\(x\.crop\)/, 'crop must be restored from project data');
assert.match(html, /crop:normalizeCrop\(d\.crop\)/, 'crop must be saved into project data');
assert.match(html, /if\(d\.type==='image'\)applyPhotoCrop\(d\)/, 'crop should be applied in preview');
assert.match(html, /drawCtx\.drawImage\(el,sx,sy,sw,sh,dx,dy,dw,dh\)/, 'crop should be applied during export');
assert.match(html, /onclick="setSelectedStartAtPlayhead\(\)"/);
assert.match(html, /onclick="setSelectedEndAtPlayhead\(\)"/);
assert.match(html, /onclick="splitSelectedAtPlayhead\(\)"/);

const start = html.indexOf('function normalizeCrop(value){');
const end = html.indexOf('\nfunction applyPhotoCrop', start);
assert.ok(start >= 0 && end > start, 'normalizeCrop function missing');
const ctx = vm.createContext({Math, Number});
vm.runInContext(html.slice(start, end) + '\nthis.normalizeCrop=normalizeCrop;', ctx, {timeout:1000});
assert.deepEqual(JSON.parse(JSON.stringify(ctx.normalizeCrop({l:0.2,t:-1,r:0.2,b:0.1}))), {l:0.2,t:0,r:0.2,b:0.1});
const clamped = ctx.normalizeCrop({l:0.9,r:0.9,t:0.1,b:0.2});
assert.ok(clamped.l >= 0 && clamped.r >= 0 && clamped.l + clamped.r <= 0.901);
assert.ok(clamped.t + clamped.b <= 0.901);

// Exercise crop presets against a real image aspect ratio without a browser DOM.
const cropStart = html.indexOf("function cropSelectedPhoto(ratio='original'){");
const cropEnd = html.indexOf('\nfunction normalizeItem(', cropStart);
assert.ok(cropStart >= 0 && cropEnd > cropStart, 'crop action not found');
const photo = {type:'image', el:{naturalWidth:1600,naturalHeight:900,style:{}}, crop:{l:0,t:0,r:0,b:0}};
const cropState = { photo, status:{textContent:''}, calls:[],
  normalizeCrop:ctx.normalizeCrop,
  save(){this.calls.push('save')}, applyPhotoCrop(d){d.crop=this.normalizeCrop(d.crop);d.el.style.clipPath='applied'},
  render(){this.calls.push('render')}, renderTimeline(){this.calls.push('timeline')}, scheduleAutoSave(){this.calls.push('autosave')},
  toast(m){this.calls.push(m)}, $(id){return id==='photoCropStatus'?this.status:{}} };
const cropContext = vm.createContext({
  selected:photo, normalizeCrop:cropState.normalizeCrop,
  save:()=>cropState.save(), applyPhotoCrop:d=>cropState.applyPhotoCrop(d),
  render:()=>cropState.render(), renderTimeline:()=>cropState.renderTimeline(),
  scheduleAutoSave:()=>cropState.scheduleAutoSave(), toast:m=>cropState.toast(m),
  $:id=>cropState.$(id), Math, Number,
});
vm.runInContext(html.slice(cropStart, cropEnd) + '\nthis.cropSelectedPhoto=cropSelectedPhoto;', cropContext, {timeout:1000});
cropContext.cropSelectedPhoto('1:1');
assert.ok(Math.abs(photo.crop.l - 0.21875) < 0.001 && Math.abs(photo.crop.r - 0.21875) < 0.001,
  'square crop should trim equal left and right margins for a 16:9 photo');
cropContext.cropSelectedPhoto('9:16');
assert.ok(photo.crop.l > 0.3 && photo.crop.r > 0.3 && photo.crop.t === 0,
  'portrait crop should retain center and trim photo width for a landscape source');
cropContext.cropSelectedPhoto('original');
assert.deepEqual(JSON.parse(JSON.stringify(photo.crop)), {l:0,t:0,r:0,b:0}, 'original/reset should remove all crop margins');
assert.ok(cropState.calls.includes('autosave') && cropState.calls.includes('save'), 'crop changes should support undo/autosave');

console.log('PASS: version 1.1.0 and Android versionCode 2 are set');
console.log('PASS: photo crop presets, persistence, preview and export paths are connected');
console.log('PASS: video/audio/photo trim and split controls remain present');
console.log('PASS: crop values are safely normalized and clamped');
