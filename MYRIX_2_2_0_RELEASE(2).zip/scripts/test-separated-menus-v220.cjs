const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'MYRIX_2_2_0_RELEASE.html'), 'utf8');
const has = (s, label) => { if (!s) throw new Error('FAIL: ' + label); console.log('PASS: ' + label); };
const required = {
  speedTool: "openCompactTool('speedTool')",
  nullTool: "openCompactTool('nullTool')",
  borderTool: "openCompactTool('borderTool')",
  threeDObjectTool: "openCompactTool('threeDObjectTool')",
  color: "openCompactTool('color')"
};
for (const [id, call] of Object.entries(required)) {
  has(html.includes(`id=\"${id}\"`) && html.includes(`data-page=\"${id}\"`) && html.includes(call), `${id}: halaman, tab, dan tombol menu terhubung terpisah`);
}
for (const id of ['selectedSpeed','parentNullSelect','borderColor','effect3dPreset','fillColor']) {
  const count = (html.match(new RegExp(`\\bid=[\"']${id}[\"']`, 'g')) || []).length;
  has(count === 1, `${id}: ID kontrol unik`);
}
has(html.includes('myrix-black-blue-separated-menus'), 'tema hitam-biru diterapkan melalui stylesheet final');
has(/\.home-screen\{[^}]*!important/.test(html) && /\.home-plus,\.home-nav-create\{[^}]*#4bdcff/.test(html), 'aksen hijau menu awal diganti biru/cyan');
has(/nth-child\(4\) \.compact-tool-icon\{color:#6bd9ff!important/.test(html), 'ikon Null/3D tidak memakai aksen hijau');
has(/<small>Kecepatan<\/small>/.test(html) && /<small>Null Object<\/small>/.test(html) && /<small>Border &amp; Shadow<\/small>/.test(html) && /<small>3D Object<\/small>/.test(html) && /<small>Color Fill<\/small>/.test(html), 'menu utama memiliki lima kategori terpisah');
console.log('PASS: separated-menu UI regression checks finished');
