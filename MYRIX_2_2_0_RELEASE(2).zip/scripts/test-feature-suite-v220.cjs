#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const html = read('app/src/main/assets/index.html');
const java = read('app/src/main/java/com/myrix/editor/MainActivity.java');
const gradle = read('app/build.gradle');
const manifest = read('app/src/main/AndroidManifest.xml');

assert.match(html, /name="application-version" content="2\.2\.0"/);
assert.match(gradle, /versionCode\s+15/);
assert.match(gradle, /versionName\s+'2\.2\.0'/);

// Manual keyframes: property edits must not synthesize a key at the playhead.
const propMatch = html.match(/function prop\(p,v\)\{[\s\S]*?\n/);
assert.ok(propMatch, 'transform property handler exists');
assert.match(propMatch[0], /keyIndex=keyIndexAt\(selected,time\)/);
assert.match(propMatch[0], /if\(keyIndex<0\)[\s\S]*?return\}/, 'animated values require a manually placed keyframe');
assert.doesNotMatch(propMatch[0], /ensureEditableKey\(/, 'normal property edits must not auto-create keyframes');
assert.match(html, /function addKeyframe\(\)\{/);
assert.match(html, /function deleteKeyframe\(\)\{[\s\S]*?selected\.keys\.splice\(i,1\)/);
assert.match(html, /onclick="deleteKeyframe\(\)"/);

// Audio and Null Object remain timeline/controller items, not objects on the preview canvas.
const createStart = html.indexOf('function createItem(');
const createEnd = html.indexOf('\nfunction ', createStart + 10);
assert.ok(createStart >= 0 && createEnd > createStart, 'createItem function exists');
const createSource = html.slice(createStart, createEnd);
assert.match(createSource, /type==='audio'\|\|type==='null'/);
assert.match(createSource, /else scene\.appendChild\(el\)/);
assert.match(html, /if\(x\.type!=='audio'&&x\.type!=='null'\)scene\.appendChild\(el\)/, 'restored projects must not place audio/Null Object on canvas');
assert.match(html, /function extractAudio\(\)/);
assert.match(html, /presentExtractedAudio\(outputBlob,[\s\S]*?sourceItem\)/);

// New editable styling controls, persistence, and effect controls.
for (const id of ['fillColor','fillColor2','fillMode','fillAngle','fillOpacity','borderColor','borderWidth','borderOpacity','shadowColor','shadowBlur','shadowX','shadowY','shadowOpacity','blendMode','selectedSpeed','effect3dPreset','parentNullSelect']) {
  assert.ok(html.includes(`id="${id}"`), `missing control ${id}`);
}
for (const fn of ['createNullObject','applySelectedFill','setFillPreset','applyLayerStyle','resetLayerStyle','setSelectedSpeed','set3DEffect','setSelectedParent','deleteKeyframe','showAppSettings','homeMenu']) {
  assert.match(html, new RegExp(`function ${fn}\\(`), `missing feature handler ${fn}`);
  assert.ok(html.includes(`window.${fn}=${fn}`), `${fn} must be exposed for UI buttons`);
}
for (const property of ['fillColor','fillColor2','fillMode','fillAngle','fillOpacity','borderColor','borderWidth','borderOpacity','shadowColor','shadowBlur','shadowX','shadowY','shadowOpacity','blendMode','speed','effect3d','parentId']) {
  assert.match(html, new RegExp(`${property}:`), `project schema missing ${property}`);
}
assert.match(html, /localStorage\.setItem\('myrix-app-settings-v1'/, 'app settings persist on device');
assert.match(html, /data-action="settings"/);
assert.match(html, /data-action="projects"/);
assert.match(html, /data-action="tutorial"/);
assert.match(html, /data-action="about"/);
assert.match(html, /perspective\('\+threeDP\+'px\)[\s\S]*?rotateX\('\+threeDX\+'deg\)/, '3D effect preview uses configurable perspective and X rotation');
assert.match(html, /function set3DParameter\(/, '3D custom parameters have a live settings handler');
assert.match(html, /id="effect3dPerspective"/, '3D perspective is adjustable in the UI');
assert.match(html, /id="mediaSpeedSelect" onchange="setSelectedSpeed\(this\.value\)"/, 'media panel exposes clip speed control');
assert.match(html, /function createNullObject\(\)[\s\S]*?if\(previous&&items\.includes\(previous\)\)select\(previous\)/, 'creating a Null Object preserves selected child to make linking easy');
assert.match(html, /function serializeProjectItem\(d\)[\s\S]*?fillColor:[\s\S]*?speed:d\.speed[\s\S]*?parentId:d\.parentId/, 'portable project saves fill, speed and parent link');
assert.match(html, /drawCtx\.globalCompositeOperation=\(\{'normal':'source-over','multiply':'multiply','screen':'screen'/, 'export supports layer blending modes');
assert.match(html, /sourceTimeAt\(d,t\)/, 'clip speed is used to map timeline time to source time');

// Android native file-saving bridge fixes WebView download handling.
assert.match(java, /webView\.addJavascriptInterface\(new MyrixFileBridge\(\), "JJAndroid"\)/);
assert.match(java, /public final class MyrixFileBridge/);
assert.match(java, /@JavascriptInterface\s+public void saveFile\(/);
assert.match(java, /@JavascriptInterface\s+public void saveVideoToGallery\(/);
assert.match(java, /MediaStore\.Video\.Media\.EXTERNAL_CONTENT_URI/);
assert.match(java, /MediaStore\.Downloads\.EXTERNAL_CONTENT_URI/);
assert.match(java, /Environment\.DIRECTORY_MOVIES/);
assert.match(java, /Environment\.DIRECTORY_DOWNLOADS/);
assert.match(manifest, /WRITE_EXTERNAL_STORAGE.*maxSdkVersion="28"/);
assert.ok(java.indexOf('addJavascriptInterface') < java.indexOf('webView.loadUrl("file:///android_asset/index.html")'), 'native bridge must be registered before HTML load');

// Execute core behavior snippets with isolated VM stubs, not only text matching.
const vm = require('node:vm');
{
  const start = html.indexOf('function worldState(');
  const end = html.indexOf('\nfunction worldToLocalPosition(', start);
  assert.ok(start >= 0 && end > start, 'worldState function slice');
  const parent = {id:1,type:'null',transform:{x:10,y:20,z:3,s:2,r:90,o:.5,shake:1}};
  const child = {id:2,type:'text',parentId:1,transform:{x:5,y:0,z:2,s:1,r:15,o:.8,shake:2}};
  const ctx = {items:[parent,child],state:(d)=>({...d.transform}),Math,Number,Set};
  vm.createContext(ctx);
  vm.runInContext(html.slice(start,end)+'\nthis.worldState=worldState;',ctx);
  const got = ctx.worldState(child,0);
  const close = (a,b) => assert.ok(Math.abs(a-b)<1e-8, `${a} should equal ${b}`);
  close(got.x,10); close(got.y,30); close(got.z,5); close(got.s,2); close(got.r,105); close(got.o,.4); close(got.shake,3);
}
{
  const start = html.indexOf('function itemTimelineStart(');
  const end = html.indexOf('\nfunction audioEnvelope(', start);
  assert.ok(start >= 0 && end > start, 'timeline mapping function slice');
  const ctx = {DURATION:120,Math,Number};
  vm.createContext(ctx);
  vm.runInContext(html.slice(start,end)+'\nthis.itemTimelineStart=itemTimelineStart;this.itemTimelineEnd=itemTimelineEnd;this.sourceTimeAt=sourceTimeAt;',ctx);
  const clip = {type:'video',_timelineStart:2,speed:2,trimIn:1,trimOut:7,el:{duration:10}};
  assert.equal(ctx.itemTimelineStart(clip),2);
  assert.equal(ctx.itemTimelineEnd(clip),5);
  assert.equal(ctx.sourceTimeAt(clip,3),3);
  assert.equal(ctx.sourceTimeAt(clip,4.5),6);
}
{
  const start = html.indexOf('let missingKeyToastAt=-1;function prop(p,v){');
  const end = html.indexOf('\nfunction sync(){', start);
  assert.ok(start >= 0 && end > start, 'manual property edit handler slice');
  const code = html.slice(start,end);
  let syncCalls=0, beginEditCalls=0; const toastMessages=[];
  const ctx = {selected:{keys:[{t:0,x:0}],x:0},time:1,Math,Number,
    keyIndexAt:()=>-1,sync:()=>{syncCalls++},toast:(m)=>toastMessages.push(m),beginEdit:()=>{beginEditCalls++},
    render(){throw new Error('render must not run when no key exists')},finishEdit(){throw new Error('finishEdit must not run when no key exists')},
    updateKeyFromProp(){throw new Error('keyframe must not be created implicitly')}};
  vm.createContext(ctx);
  vm.runInContext(code+'\nthis.testProp=prop;',ctx);
  ctx.testProp('x',50);
  assert.equal(ctx.selected.keys.length,1,'must not create keyframe implicitly');
  assert.equal(ctx.selected.x,0,'must not mutate base transform in animation mode');
  assert.equal(beginEditCalls,0,'must not start edit without a key');
  assert.equal(syncCalls,1,'refresh controls after rejecting the edit');
  assert.ok(toastMessages[0].includes('Tambahkan keyframe'), 'inform user to add keyframe manually');
}
{
  const start = html.indexOf('function createItem(');
  const end = html.indexOf('\nfunction ', start + 10);
  assert.ok(start >= 0 && end > start, 'createItem function slice');
  const domSlot = {style:{},textContent:'',className:'',dataset:{}};
  let sceneAdds=0;
  const ctx = {items:[],nextId:10,time:0,MAX_LAYERS:30,layerCount:2,DURATION:120,
    normalizeFx:()=>({}),$:()=>domSlot,scene:{appendChild(){sceneAdds++}},
    syncZ(){},bind(){},select(){},render(){},renderTimeline(){},scheduleAutoSave(){}};
  vm.createContext(ctx);
  vm.runInContext(html.slice(start,end)+'\nthis.createItem=createItem;',ctx);
  const audioEl={style:{},dataset:{}};
  const audio=ctx.createItem(audioEl,'audio');
  assert.equal(sceneAdds,0,'extracted audio should not be appended to center scene');
  assert.equal(audio.type,'audio');
  assert.equal(audioEl.style.display,'none');
  const nullEl={style:{},dataset:{}};
  const nullObj=ctx.createItem(nullEl,'null');
  assert.equal(sceneAdds,0,'Null Object should not be appended to center scene');
  assert.equal(nullObj.type,'null');
  const textEl={style:{},dataset:{}};
  ctx.createItem(textEl,'text');
  assert.equal(sceneAdds,1,'normal visual layer should still append to scene');
}
console.log('PASS: behavioral tests: Null Object parenting transforms, clip speed mapping, no implicit keyframes, and canvas/audio item separation');

// Verify download Blob conversion uses the compatibility-oriented FileReader path.
(async()=>{
  const start=html.indexOf('function blobToBase64(blob){');
  const end=html.indexOf('\nfunction downloadBlob(',start);
  assert.ok(start>=0&&end>start,'Blob-to-base64 compatibility helper exists');
  class MockFileReader{
    readAsDataURL(blob){this.result='data:'+(blob.type||'application/octet-stream')+';base64,QUJD';this.onload()}
  }
  const ctx={Promise,FileReader:MockFileReader,String,Error};
  vm.createContext(ctx);
  vm.runInContext(html.slice(start,end)+'\nthis.blobToBase64=blobToBase64;',ctx);
  assert.equal(await ctx.blobToBase64({type:'video/mp4'}),'QUJD');
  console.log('PASS: native-download Blob conversion uses FileReader for older Android WebViews');
})().catch(error=>{console.error(error);process.exitCode=1});

console.log('PASS: manual keyframe creation/deletion behavior is wired');
console.log('PASS: audio and Null Object stay out of the center canvas and persist in timeline schema');
console.log('PASS: Null Object, Color Fill, Border/Shadow, blending, speed, and 3D handlers/UI exist');
console.log('PASS: settings/menu controls and local preference persistence are wired');
console.log('PASS: APK download bridge saves video using Android MediaStore and has legacy storage path');
console.log('PASS: version 2.2.0 / versionCode 15 are consistent');
