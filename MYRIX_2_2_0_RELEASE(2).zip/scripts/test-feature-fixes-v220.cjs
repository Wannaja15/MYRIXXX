#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const block = (start, end) => {
  const a = html.indexOf(start);
  const b = html.indexOf(end, a + start.length);
  assert.ok(a >= 0 && b > a, `expected source block ${start}`);
  return html.slice(a, b);
};

// Null Object creation should leave a previously selected visual child selected.
const createNull = block('function createNullObject(){', '\nfunction setSelectedParent(');
assert.match(createNull, /const previous=selected&&selected\.type!=='null'&&selected\.type!=='audio'\?selected:null/);
assert.match(createNull, /if\(previous&&items\.includes\(previous\)\)select\(previous\)/);
const parentHandler = block('function setSelectedParent(value){', '\nfunction refreshParentNullOptions(');
assert.match(parentHandler, /selected\.parentId=id/);
assert.match(parentHandler, /renderTimeline\(\)/);
assert.match(parentHandler, /scheduleAutoSave\(\)/);

// Color Fill must update both persistent fields and live render styles, including gradient reset.
const fillHandler = block('function applySelectedFill(){', '\nfunction setFillPreset(');
for (const pattern of [/d\.fillColor=a/, /d\.fillColor2=b/, /d\.fillMode=/, /d\.fillOpacity=/, /d\.shapeColor=a/, /d\.el\.style\.backgroundImage/]) assert.match(fillHandler, pattern);
assert.match(html, /function cssFill\(d\)/);
assert.match(html, /canvasFill\(drawCtx,d,baseW,baseH/);

// 3D is tunable (X/Y/Z/perspective), persists, and is used by preview and export.
for (const id of ['effect3dX','effect3dY','effect3dZ','effect3dPerspective','effect3dXValue','effect3dYValue','effect3dZValue','effect3dPerspectiveValue']) assert.ok(html.includes(`id="${id}"`), `missing ${id}`);
assert.match(html, /function set3DParameter\(parameter,value\)/);
assert.match(html, /window\.set3DParameter=set3DParameter/);
assert.match(html, /effect3dPerspective:d\.effect3dPerspective\?\?820/);
assert.match(html, /perspective\('\+threeDP\+'px\)/);
assert.match(html, /tiltX=threeDOn\?/);

// Speed should be visible in both Layer and Media panels and synced when selected.
assert.match(html, /id="selectedSpeed" onchange="setSelectedSpeed\(this\.value\)"/);
assert.match(html, /id="mediaSpeedSelect" onchange="setSelectedSpeed\(this\.value\)"/);
assert.match(html, /\$\('mediaSpeedSelect'\)\.value=String\(Math\.max\(/);
assert.match(html, /function setSelectedSpeed\(value\)/);

// Portable project save and autosave snapshot must preserve every feature setting.
const serializer = block('function serializeProjectItem(d){', '\nasync function buildPortableProjectData(');
for (const prop of ['fillColor:', 'fillColor2:', 'fillMode:', 'fillAngle:', 'fillOpacity:', 'speed:', 'effect3d:', 'effect3dX:', 'effect3dY:', 'effect3dZ:', 'effect3dPerspective:', 'parentId:']) assert.ok(serializer.includes(prop), `portable save omits ${prop}`);
const snap = block('function snapshot(){', '\ndocument.querySelectorAll');
for (const prop of ['effect3dX:d.effect3dX', 'effect3dY:d.effect3dY', 'effect3dZ:d.effect3dZ', 'effect3dPerspective:d.effect3dPerspective', 'parentId:d.parentId']) assert.ok(snap.includes(prop), `snapshot omits ${prop}`);

// Exercise 3D preset and manual setting handlers in a tiny VM context.
const setterBlock = block('function set3DEffect(value){', '\nfunction keyIndexAt(');
const selected = {type:'shape',effect3d:'off'};
const values = {};
const ctx = {selected,save(){},beginEdit(){},finishEdit(){},refreshLayerStyleControls(){},render(){},renderTimeline(){},scheduleAutoSave(){},toast(){},
  $:id=>({value:'off',textContent:'',}),Math,Number};
vm.createContext(ctx);
vm.runInContext(setterBlock+'\nthis.set3DEffect=set3DEffect;this.set3DParameter=set3DParameter;',ctx);
ctx.set3DEffect('card');
assert.equal(selected.effect3d,'card');
assert.equal(selected.effect3dX,7);
assert.equal(selected.effect3dY,-16);
ctx.set3DParameter('effect3dX','42');
assert.equal(selected.effect3dX,42);
assert.equal(selected.effect3d,'card');
console.log('PASS: Null Object link flow, Color Fill, editable/persistent 3D settings, and visible/synced clip speed controls');
