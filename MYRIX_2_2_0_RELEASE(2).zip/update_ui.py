from pathlib import Path
import re, shutil, zipfile, os
p=Path('/mnt/data/myrix_uiwork/MYRIX_2_2_0_RELEASE.html')
s=p.read_text()

def extract_section(text, marker):
    start=text.find(marker)
    if start<0: raise ValueError('missing section '+marker)
    end=text.find('</section>', start)
    if end<0: raise ValueError('missing close section '+marker)
    end += len('</section>')
    return text[:start]+text[end:], text[start:end]

# Move 3D settings into a dedicated page.
s, section3d = extract_section(s, '<section class="myrix-controls" aria-label="Efek tiga dimensi">')
# Move Border & Shadow settings into a dedicated page.
s, border = extract_section(s, '<section class="myrix-controls" aria-label="Border dan shadow">')
# Strip speed/null from the old combined layer section, preserving blending there.
start=s.find('<section class="myrix-controls" aria-label="Blending dan kecepatan">')
if start<0: raise ValueError('missing blending section')
end=s.find('</section>',start)+len('</section>')
old=s[start:end]
blend_match=re.search(r'<div class="myrix-controls-title"><b>BLENDING</b>.*?</label>',old,re.S)
if not blend_match: raise ValueError('could not find blending controls')
blend_only='<section class="myrix-controls" aria-label="Blending">\n   '+blend_match.group(0)+'\n  </section>'
s=s[:start]+blend_only+s[end:]

# Dock: the primary tools each open their own page.
dock_start=s.find('<div class="compact-tool-dock" id="compactToolDock"')
dock_end=s.find('</div>',dock_start)+len('</div>')
new_dock='''<div class="compact-tool-dock" id="compactToolDock" aria-label="Menu alat edit">
  <button type="button" class="compact-tool" onclick="openCompactTool('speedTool')"><span class="compact-tool-icon">◴</span><small>Kecepatan</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('nullTool')"><span class="compact-tool-icon">◎</span><small>Null Object</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('borderTool')"><span class="compact-tool-icon">▣</span><small>Border &amp; Shadow</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('threeDObjectTool')"><span class="compact-tool-icon">◇</span><small>3D Object</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('color')"><span class="compact-tool-icon">◈</span><small>Color Fill</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('media')"><span class="compact-tool-icon">✂</span><small>Potong / CUT</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('anim')"><span class="compact-tool-icon">✥</span><small>Move &amp; Transform</small></button>
  <button type="button" class="compact-tool" onclick="openCompactTool('fx')"><span class="compact-tool-icon">✦</span><small>Effects</small></button>
 </div>'''
s=s[:dock_start]+new_dock+s[dock_end:]

# Extend tab navigation so each tool has its own independent panel.
tab_old=''' <div class="tabs">
  <button class="tab active" data-page="anim">Animasi</button><button class="tab" data-page="fx">Effects</button><button class="tab" data-page="color">Color</button><button class="tab" data-page="layer">Layer</button><button class="tab" data-page="media">Media</button><button class="tab" data-page="tracking">3D Track</button>
 </div>'''
tab_new=''' <div class="tabs" aria-label="Kategori pengeditan">
  <button class="tab active" data-page="anim">Animasi</button><button class="tab" data-page="fx">Effects</button><button class="tab" data-page="color">Color Fill</button><button class="tab" data-page="speedTool">Kecepatan</button><button class="tab" data-page="nullTool">Null Object</button><button class="tab" data-page="borderTool">Border</button><button class="tab" data-page="threeDObjectTool">3D Object</button><button class="tab" data-page="layer">Layer</button><button class="tab" data-page="media">Media</button><button class="tab" data-page="tracking">3D Track</button>
 </div>'''
if tab_old not in s: raise ValueError('tabs block not found')
s=s.replace(tab_old,tab_new,1)

# Build independent tool panels and place beside other property pages.
speed_page='''
 <div class="page" id="speedTool">
  <section class="myrix-controls" aria-label="Kecepatan klip">
   <div class="myrix-controls-title"><b>KECEPATAN</b><small>Atur kecepatan klip video atau audio</small></div>
   <label class="myrix-field"><span>Kecepatan pemutaran</span><select id="selectedSpeed" onchange="setSelectedSpeed(this.value)"><option value="0.25">0.25× · Sangat lambat</option><option value="0.5">0.5× · Lambat</option><option value="0.75">0.75×</option><option value="1">1× · Normal</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2× · Cepat</option><option value="3">3×</option><option value="4">4× · Sangat cepat</option></select></label>
   <div class="speed-preset-row"><button type="button" onclick="setSelectedSpeed('0.5')">½×</button><button type="button" onclick="setSelectedSpeed('1')">1× Normal</button><button type="button" onclick="setSelectedSpeed('2')">2×</button><button type="button" onclick="setSelectedSpeed('4')">4×</button></div>
   <div class="hint">Pilih klip video atau audio di timeline dahulu. Kecepatan memengaruhi durasi klip dan sinkronisasi sumber saat diputar atau diekspor.</div>
  </section>
 </div>
 <div class="page" id="nullTool">
  <section class="myrix-controls" aria-label="Null Object dan parent">
   <div class="myrix-controls-title"><b>NULL OBJECT</b><small>Satu pengendali untuk beberapa layer</small></div>
   <button type="button" class="tool-primary-action" onclick="createNullObject()">＋ Buat Null Object</button>
   <label class="myrix-field"><span>Hubungkan layer terpilih ke</span><select id="parentNullSelect" onchange="setSelectedParent(this.value)"><option value="">Tidak ada parent</option></select></label>
   <div class="hint" id="parentNullHint">Pilih layer foto, video, teks, atau shape di timeline, lalu pilih Null Object sebagai Parent. Gerakkan Null Object untuk mengendalikan layer anak.</div>
   <div class="hint">Null Object adalah pengendali, bukan objek visual. Ia muncul sebagai layer tersendiri di timeline.</div>
  </section>
 </div>
 <div class="page" id="borderTool">
  '''+border+'''
 </div>
 <div class="page" id="threeDObjectTool">
  '''+section3d+'''
 </div>
'''
insert_before='</section>\n<div class="panelGrip" id="panelGrip"'
if insert_before not in s: raise ValueError('editor page insertion marker not found')
s=s.replace(insert_before, speed_page+'\n</section>\n<div class="panelGrip" id="panelGrip"',1)

# Update missing-selection prompt behavior for independent tool pages.
s=s.replace("prompt.hidden=!!selected||['media','layer'].includes(active);", "prompt.hidden=!!selected||['media','layer','color','speedTool','nullTool','borderTool','threeDObjectTool'].includes(active);")
# Ensure pages can be addressed by compact tool controller and show correct panel heading.
s=s.replace("const labels={anim:'Move & Transform / Animasi',fx:'Effects',color:'Color & Fill',layer:'Pengaturan Layer',media:'Media / Potong & CUT',tracking:'3D Track'};", "const labels={anim:'Move & Transform / Animasi',fx:'Effects',color:'Color Fill',speedTool:'Kecepatan',nullTool:'Null Object / Parent',borderTool:'Border & Shadow',threeDObjectTool:'3D Object',layer:'Layer & Blending',media:'Media / Potong & CUT',tracking:'3D Track'};")

# Theme: remove green/teal from home and editor controls, use black/navy and blue/cyan.
theme='''
<style id="myrix-black-blue-separated-menus">
:root{--my-bg:#070b13;--my-panel:#101827;--my-line:#263852;--my-cyan:#4bdcff;--my-muted:#96a9c4;--myrix-ink:#edf5ff;--myrix-muted:#99adca;--myrix-teal:#12243d;--myrix-teal-2:#080e19;--myrix-blue:#438cff;--myrix-yellow:#78ddff}
.home-screen{background:radial-gradient(ellipse at 88% -8%,rgba(37,112,210,.22),transparent 43%),linear-gradient(160deg,#080d17,#0a1322 58%,#080d17)!important;color:#edf5ff!important}
.home-header{background:rgba(8,14,25,.96)!important;border-bottom-color:#243750!important}
.home-brand-mark{background:linear-gradient(145deg,#54ddff,#3177dc)!important;color:#071323!important;box-shadow:0 5px 18px #238cff35!important}
.home-section{background:linear-gradient(145deg,rgba(17,31,52,.98),rgba(10,18,31,.98))!important;border-color:#243b59!important;box-shadow:0 12px 30px #0003!important}
.home-section h2,.home-section-head h2{color:#edf5ff!important}
.create-project-dash{background:linear-gradient(120deg,#142b48,#0e1d31)!important;border:1px solid #315983!important;color:#edf5ff!important}
.home-plus,.home-nav-create{background:linear-gradient(145deg,#4bdcff,#347fe1)!important;color:#061728!important;box-shadow:0 5px 18px #248cff30!important}
.home-recent-list .recent-project-card{background:#0e192a!important;border-color:#263b57!important}
.recent-project-icon{background:linear-gradient(145deg,#183e66,#10233d)!important;color:#75e7ff!important}
.start-card,.tutorial-card,.project-card{background:linear-gradient(145deg,#162844,#0d1728)!important;border-color:#2a4162!important;color:#edf5ff!important}
.project-card{background:linear-gradient(145deg,#12334e,#0d1728)!important}
.start-icon,.home-section-head>button,.start-card small{color:#6ee5ff!important}
.start-card small span{background:#183b63!important;color:#8deaff!important}
.home-help{background:#0e192a!important;border-color:#263b57!important}.home-help p{color:#a2b6d0!important}
.home-bottom{background:rgba(7,12,22,.97)!important;border-top-color:#263852!important}
.home-nav-item{color:#879bb7!important}.home-nav-item.active{color:#65e2ff!important}
.home-action{background:linear-gradient(110deg,#4bdcff,#347fe1)!important;color:#071627!important}
#editorApp{background:#080d17!important;color:#edf5ff!important}
#editorApp .editor{background:#0d1523!important;border-top-color:#263852!important}
#editorApp .tabs{background:#0b1320!important;border-bottom-color:#263852!important}
#editorApp .tab{background:#121e30!important;border:1px solid #273b57!important;color:#a8bdd8!important;border-radius:10px!important}
#editorApp .tab.active{background:linear-gradient(135deg,#1c4774,#153456)!important;border-color:#4bdcff!important;color:#eafbff!important;box-shadow:inset 0 0 0 1px #4bdcff18!important}
#editorApp .compact-tool-dock{background:#0b1320!important}
#editorApp .compact-tool{background:linear-gradient(145deg,#17263c,#0e192b)!important;border-color:#2b4566!important;border-bottom-color:#3e6793!important;color:#ecf6ff!important}
#editorApp .compact-tool-icon{color:#62e2ff!important}
#editorApp .compact-tool small{color:#e1edff!important}
#editorApp .compact-tool:active{border-color:#61e4ff!important;background:linear-gradient(145deg,#214d7d,#172d4c)!important}
#editorApp .compact-panel-head{background:#0b1422!important;border-bottom-color:#263c58!important;color:#eaf5ff!important}
#editorApp .myrix-controls{background:linear-gradient(145deg,#111f34,#0b1422)!important;border-color:#2a4363!important;box-shadow:0 8px 20px #0002!important}
#editorApp .myrix-controls-title b{color:#e8f5ff!important}
#editorApp .myrix-controls-title small{color:#99b0cf!important}
#editorApp .myrix-field{color:#dbe9fb!important}
#editorApp .myrix-field output{color:#6fe6ff!important}
#editorApp .myrix-field input[type=color]{background:#101b2d!important;border-color:#365374!important}
#editorApp .myrix-field input[type=range]{accent-color:#459cff!important}
#editorApp .myrix-field select,#editorApp .myrix-controls select{background:#0a1423!important;color:#eaf5ff!important;border-color:#345273!important}
#editorApp .myrix-controls button,#editorApp .speed-preset-row button{background:#15253b!important;border:1px solid #2d4c70!important;color:#e5f3ff!important}
#editorApp .myrix-controls .tool-primary-action{background:linear-gradient(115deg,#4bdcff,#347fe1)!important;color:#071627!important;border:0!important;font-weight:800!important}
#editorApp .selectionPrompt{background:linear-gradient(145deg,#14243a,#0e1727)!important;border-color:#355578!important}
#editorApp .selectionPrompt button{background:linear-gradient(135deg,#347fd8,#2366bb)!important;color:#fff!important}
#editorApp .speed-preset-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}
#editorApp .speed-preset-row button{min-width:0;padding:8px 4px;font-size:11px;font-weight:750}
#editorApp .page{background:#0c1422!important}
#editorApp .myrix-controls .hint{color:#98acc8!important;line-height:1.5}
@media(max-width:430px){#editorApp .tabs{gap:5px!important}#editorApp .tab{min-width:70px!important;font-size:10px!important;padding:0 9px!important}}
</style>
'''
insert='</head>'
if insert not in s: raise ValueError('head end missing')
s=s.replace(insert,theme+'\n'+insert,1)

p.write_text(s)
print('updated html chars',len(s),'pages',re.findall(r'<div class="page(?: active)?" id="([^"]+)"',s))
