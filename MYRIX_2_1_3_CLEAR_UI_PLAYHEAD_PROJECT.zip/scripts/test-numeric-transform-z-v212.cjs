const fs=require('fs');const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const ids=['pxn','pyn','pzn','scn','rtn','opn','shn'];
for(const id of ids) if(!new RegExp('id="'+id+'"[^>]*type="number"|id="'+id+'"[^>]*class="valueInput"').test(html)) throw new Error('Missing numeric input '+id);
if(!html.includes("num.addEventListener('change'")) throw new Error('Numeric input change handler missing');
if(!html.includes('1000000+(depth*10000)')) throw new Error('Global Z depth formula missing');
if(!html.includes("sort((a,b)=>((Number(a.d.z)||0)-(Number(b.d.z)||0))")) throw new Error('Export Z sorting missing');
console.log('PASS MYRIX numeric transform and Z depth hooks remain present in 2.1.3');
