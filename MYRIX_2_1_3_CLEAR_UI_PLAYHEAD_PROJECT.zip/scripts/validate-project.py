#!/usr/bin/env python3
"""Dependency-free static checks for the MYRIX HTML/Android source project."""
from __future__ import annotations
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / "app/src/main/assets"
INDEX = ASSET_DIR / "index.html"
REQUIRED = [
    INDEX,
    ASSET_DIR / "logo.png",
    ROOT / "app/src/main/AndroidManifest.xml",
    ROOT / "app/src/main/res/values/styles.xml",
    ROOT / "app/src/main/java/com/myrix/editor/MainActivity.java",
    ROOT / "app/build.gradle",
    ROOT / "build.gradle",
    ROOT / "settings.gradle",
    ROOT / ".github/workflows/build-apk.yml",
]

class MarkupAudit(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.resources = []
        self.inline_scripts = []
        self._script_buffer = None
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        attr = "src" if tag in ("img", "script", "video", "audio", "source") else "href" if tag in ("link", "a") else None
        val = attrs.get(attr) if attr else None
        if val:
            self.resources.append((tag, val))
        if tag == "script" and not attrs.get("src"):
            self._script_buffer = []
    def handle_data(self, data):
        if self._script_buffer is not None:
            self._script_buffer.append(data)
    def handle_endtag(self, tag):
        if tag == "script" and self._script_buffer is not None:
            self.inline_scripts.append("".join(self._script_buffer))
            self._script_buffer = None

def fail(message):
    print("FAIL:", message)
    sys.exit(1)

for path in REQUIRED:
    if not path.is_file():
        fail(f"file proyek wajib tidak ditemukan: {path.relative_to(ROOT)}")

html = INDEX.read_text(encoding="utf-8")
parser = MarkupAudit()
parser.feed(html)
parser.close()

counts = Counter(x for x in parser.ids if x)
duplicates = sorted(k for k, v in counts.items() if v > 1)
if duplicates:
    fail("ID HTML duplikat: " + ", ".join(duplicates))

for tag, url in parser.resources:
    if url.startswith(("http://", "https://", "data:", "blob:", "#", "javascript:", "mailto:", "tel:")):
        continue
    if url.startswith("//"):
        continue
    clean = url.split("?", 1)[0].split("#", 1)[0]
    if not clean:
        continue
    target = (ASSET_DIR / clean).resolve()
    if not target.is_file():
        fail(f"referensi aset lokal rusak: <{tag}> {url} (dicari di {target})")

# Ensure JavaScript bodies embedded in the HTML parse in the same Node engine used by CI.
if not parser.inline_scripts:
    fail("tidak ada inline script yang ditemukan")
with tempfile.TemporaryDirectory(prefix="myrix-js-check-") as tmp:
    for i, script in enumerate(parser.inline_scripts):
        js_path = Path(tmp) / f"inline-{i}.js"
        js_path.write_text(script, encoding="utf-8")
        result = subprocess.run(["node", "--check", str(js_path)], capture_output=True, text=True)
        if result.returncode:
            fail(f"JavaScript inline #{i+1} gagal syntax check:\n{result.stderr}")

# Beat controls use inline onclick attributes while the app code is wrapped in an IIFE.
# Ensure every action is explicitly published on window so taps work in Acode/WebView.
beat_actions = ("toggleBeatPanel", "generateBeatMarkers", "detectBeatMarkers", "addBeatMarker", "clearBeatMarkers")
missing_beat_exports = [name for name in beat_actions if not re.search(r"window\." + re.escape(name) + r"\s*=\s*" + re.escape(name) + r"\s*;", html)]
if missing_beat_exports:
    fail("Beat actions tidak tersedia untuk tombol HTML: " + ", ".join(missing_beat_exports))
for name in beat_actions:
    if not re.search(r"function\s+" + re.escape(name) + r"\s*\(", html):
        fail("Fungsi Beat tidak ditemukan: " + name)

# Extract the effect registry/schema without evaluating the full interactive editor.
reg = re.search(r"const FX_EFFECTS\s*=\s*\[(.*?)\];\s*const FX_PARAM_SCHEMA\s*=", html, re.S)
if not reg:
    fail("FX_EFFECTS atau FX_PARAM_SCHEMA tidak ditemukan")
keys = re.findall(r"\[['\"]([A-Za-z][A-Za-z0-9]*)['\"]\s*,", reg.group(1))
if not keys:
    fail("katalog efek kosong atau formatnya tidak dikenali")
if len(keys) != len(set(keys)):
    fail("kunci efek duplikat: " + ", ".join(sorted(k for k, n in Counter(keys).items() if n > 1)))

schema_match = re.search(r"const FX_PARAM_SCHEMA\s*=\s*\{(.*?)\n\};\s*const FX_EXTRA_CATEGORIES", html, re.S)
if not schema_match:
    fail("batas FX_PARAM_SCHEMA tidak ditemukan")
schema_keys = re.findall(r"^\s*([A-Za-z][A-Za-z0-9]*)\s*:\s*\[", schema_match.group(1), re.M)
unknown_schema = sorted(set(schema_keys) - set(keys))
if unknown_schema:
    fail("schema parameter mengacu ke efek yang tidak terdaftar: " + ", ".join(unknown_schema))

cat_match = re.search(r"const FX_EXTRA_CATEGORIES\s*=\s*\[(.*?)\];\s*const FX_OVERLAY_KEYS", html, re.S)
if not cat_match:
    fail("FX_EXTRA_CATEGORIES tidak ditemukan")
category_keys = []
for entry in re.findall(r"keys\s*:\s*\[([^\]]*)\]", cat_match.group(1), re.S):
    category_keys.extend(re.findall(r"['\"]([A-Za-z][A-Za-z0-9]*)['\"]", entry))
unknown_category = sorted(set(category_keys) - set(keys))
if unknown_category:
    fail("katalog UI mengacu ke efek yang tidak terdaftar: " + ", ".join(unknown_category))
if len(category_keys) != len(set(category_keys)):
    fail("sebuah efek muncul lebih dari sekali di katalog tambahan")

# Timeline/move interactions must keep their regression-tested behavior.
required_motion_signatures = {
    "per-second timeline ruler": r"className=['\"]timelineRuler['\"]",
    "second-grid markers": r"className=['\"]secondGridLine",
    "zoom-corrected object dragging": r"stage\.clientWidth\*canvasZoom",
    "hand-mode gesture isolation": r"if\(panMode\|\|isPinchStart\)ev\.stopPropagation\(\)",
    "playback timeline follow": r"const scroller=\$\('timelineScroller'\)",
}
for label, pattern in required_motion_signatures.items():
    if not re.search(pattern, html):
        fail(f"fitur timeline/kanvas tidak ditemukan: {label}")

# Android XML well-formedness.
for xml_path in (ROOT / "app/src/main/AndroidManifest.xml", ROOT / "app/src/main/res/values/styles.xml"):
    try:
        ET.parse(xml_path)
    except ET.ParseError as exc:
        fail(f"XML tidak valid ({xml_path.relative_to(ROOT)}): {exc}")

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
if not any(el.attrib.get("{http://schemas.android.com/apk/res/android}name") == ".MainActivity" for el in manifest.iter("activity")):
    fail("MainActivity tidak terdaftar di AndroidManifest.xml")

java = (ROOT / "app/src/main/java/com/myrix/editor/MainActivity.java").read_text(encoding="utf-8")
if "package com.myrix.editor;" not in java or "class MainActivity" not in java:
    fail("package/class MainActivity tidak cocok dengan jalur file Android")

print("PASS: file proyek wajib ditemukan (", len(REQUIRED), ")", sep="")
print(f"PASS: HTML IDs unik ({len(counts)} ID)")
print(f"PASS: {len(parser.inline_scripts)} inline JavaScript lolos node --check")
print("PASS: 5 aksi Beat terhubung ke window dan tombol HTML")
print("PASS: ruler per detik, grid layer, drag sesuai zoom, mode tangan, dan auto-follow timeline")
print(f"PASS: {len(keys)} kunci efek unik; {len(schema_keys)} schema efek; {len(set(category_keys))} efek dalam kategori tambahan")
print("PASS: AndroidManifest.xml dan styles.xml terbaca sebagai XML valid")
print("PASS: nama package, MainActivity, asset logo, dan referensi file lokal cocok")
print("CATATAN: ini pemeriksaan statis; bukan pengganti build Gradle atau uji langsung di HP Android.")
