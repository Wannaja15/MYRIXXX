#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');
assert.match(html, /id="myrix-fixed-beat-transport-dock"/, 'fixed transport dock styles are missing');
const dock = html.slice(html.indexOf('<style id="myrix-fixed-beat-transport-dock">'), html.indexOf('</style>', html.indexOf('<style id="myrix-fixed-beat-transport-dock">')));
assert.match(html, /<div class=\"timelineControlsDock\" id=\"timelineControlsDock\">[\s\S]*?class=\"timebar\"[\s\S]*?id=\"beatPanel\"/, 'transport and Beat settings must live in a fixed dock');
assert.match(html, /<div class=\"timelineScroller\" id=\"timelineScroller\"[^>]*><div class=\"tracks\" id=\"tracks\"/, 'only the tracks should live in the horizontally scrolling viewport');
assert.match(dock, /\.timeline\s*\{[^}]*overflow:hidden!important/s, 'outer timeline must not horizontally scroll the controls');
assert.match(dock, /\.timelineControlsDock\s*\{[^}]*width:100%/s, 'controls dock must stay within visible viewport');
assert.match(dock, /\.timelineScroller\s*\{[^}]*overflow:auto!important/s, 'track scroller must own horizontal scrolling');
assert.match(html, /const bar=document\.querySelector\('\.timebar'\);if\(bar\)\{bar\.style\.minWidth='100%';bar\.style\.width='100%';bar\.style\.maxWidth='100%'\}/, 'duration updates must not stretch transport controls across the timeline');
assert.match(html, /const contentWidth=Math\.max\(1400,LABEL_W\+DURATION\*PX_PER_SEC\+180\)/, 'timeline ruler/layers should retain expanded scrollable width');
assert.match(html, /const scroller=\$\('timelineScroller'\)/, 'playback should scroll the tracks under the fixed controls');
console.log('PASS: transport and Beat settings are structurally outside the horizontally scrolling timeline');
console.log('PASS: ruler and tracks retain independent long-duration scroll width');
console.log('PASS: playhead auto-follow scroll targets only the track viewport');
