const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const checks = [
  ['version 2.1.3 metadata', html.includes('name="application-version" content="2.1.3"')],
  ['high-contrast menu style', html.includes('myrix-2-1-3-ui-clarity-playhead') && html.includes('color:#f1f5ff!important')],
  ['larger readable menu labels', html.includes('font-size:10px!important;line-height:1.18!important;font-weight:750!important')],
  ['high-visibility time display', html.includes('#editorApp .timebar #timeText') && html.includes("label.setAttribute('aria-label','Waktu '+shown.toFixed(2)+' detik')")],
  ['playhead updates elapsed time readout', /function updatePlayhead\(\)[\s\S]*?const label=\$\('timeText'\),hud=\$\('hudTime'\),slider=\$\('timeSlider'\)/.test(html)],
  ['playhead scroll-follow uses viewport threshold', /const x=LABEL_W\+shown\*PX_PER_SEC,visible=x-scroller\.scrollLeft,threshold=scroller\.clientWidth\*\.58;/.test(html) && /x-scroller\.clientWidth\*\.55/.test(html)],
  ['playback clock is based on RAF timestamp', html.includes('playbackBaseTime+Math.max(0,(ts-playbackStartTs)/1000)')],
  ['every RAF moves playhead and readouts', /\$\('timeSlider'\)\.value=String\(time\);updatePlayhead\(\);/.test(html)],
  ['playback time rebased when scrubbing', html.includes('if(playing){playbackBaseTime=time;playbackStartTs=null;lastTs=0}')],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);

// Execute the real updatePlayhead/tick functions with small DOM/RAF mocks.
const vm = require('node:vm');
const assert = require('node:assert/strict');
const updateStart = html.indexOf('function updatePlayhead(){');
const updateEnd = html.indexOf('\nfunction updateKeySelection()', updateStart);
const tickStart = html.indexOf('function tick(ts){');
const tickEnd = html.indexOf('\n\nfunction toggleGrid()', tickStart);
assert(updateStart >= 0 && updateEnd > updateStart, 'updatePlayhead source must be extractable');
assert(tickStart >= 0 && tickEnd > tickStart, 'tick source must be extractable');
const elements = Object.create(null);
const mock$ = id => elements[id] || (elements[id] = {
  value: '0', textContent: '', style: {}, clientWidth: 800, scrollLeft: 0,
  setAttribute() {},
});
const state = {
  items: [], selected: null, time: 0, playing: true, raf: 0,
  playbackStartTs: null, playbackBaseTime: 0, lastTs: 0,
  lastRenderTs: 0, lastVideoSyncTs: 0, DURATION: 20,
  PX_PER_SEC: 82, LABEL_W: 78, RULER_H: 26, TRACK_H: 38,
  MIN_LAYERS: 1, layerCount: 1,
  requestAnimationFrame() { return 7; }, cancelAnimationFrame() {},
  render() {}, pauseAllMedia() {}, updatePlayButton() {},
  syncAudioPlayback() {}, syncVideoPlayback() {}, $: mock$,
  Math, Number, String,
};
const ctx = vm.createContext(state);
vm.runInContext(html.slice(updateStart, updateEnd) + '\n' + html.slice(tickStart, tickEnd), ctx, {timeout: 1000});
ctx.tick(1000); // establishes RAF playback origin
ctx.tick(2000); // one second elapsed
assert.ok(Math.abs(ctx.time - 1) < 0.001, 'playback clock should advance by elapsed RAF time');
assert.equal(mock$('timeSlider').value, '1', 'time slider should be updated during playback');
assert.equal(mock$('timeText').textContent, '00:01.00', 'visible seconds counter should update during playback');
assert.equal(mock$('playline').style.transform, 'translate3d(82px,0,0)', 'playhead line should move to the elapsed second');
ctx.playbackBaseTime = 6;
ctx.playbackStartTs = 2000;
ctx.time = 6;
ctx.updatePlayhead();
assert.ok(mock$('timelineScroller').scrollLeft > 0, 'timeline should auto-follow when the playhead crosses the viewport threshold');
console.log('PASS: live playback simulation advances seconds, slider, readout, playhead line, and horizontal auto-follow');
