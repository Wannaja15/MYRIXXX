#!/usr/bin/env node
// Small regression tests for the Beat controls extracted from the real MYRIX HTML.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = require('path').join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const actions = ['toggleBeatPanel', 'generateBeatMarkers', 'detectBeatMarkers', 'addBeatMarker', 'clearBeatMarkers'];
for (const name of actions) {
  assert.match(html, new RegExp(`window\\.${name}\\s*=\\s*${name}\\s*;`), `${name} must be exported to window`);
  assert.match(html, new RegExp(`function\\s+${name}\\s*\\(`), `${name} declaration must exist`);
}

function extractFunction(name, nextName) {
  const re = new RegExp(`function ${name}\\([^)]*\\)\\{([\\s\\S]*?)\\n(?=(?:async )?function ${nextName}\\()`);
  const match = html.match(re);
  assert.ok(match, `Could not extract ${name}`);
  return `function ${name}(){${match[1]}`;
}
const snippets = [
  extractFunction('toggleBeatPanel', 'addBeatMarker'),
  extractFunction('addBeatMarker', 'clearBeatMarkers'),
  extractFunction('clearBeatMarkers', 'generateBeatMarkers'),
  extractFunction('generateBeatMarkers', 'detectBeatMarkers'),
];
const state = {
  DURATION: 3,
  time: 1.25,
  beatMarkers: [],
  saveCalls: 0,
  renderCalls: 0,
  autosaveCalls: 0,
  messages: [],
  beatPanel: { hidden: true },
  beatToggleBtn: { classList: { add(){}, remove(){} } },
  beatBpm: { value: '120' },
  beatOffset: { value: '0' },
};
const context = vm.createContext({
  ...state,
  $: id => state[id] || null,
  save: () => { state.saveCalls++; },
  renderTimeline: () => { state.renderCalls++; },
  scheduleAutoSave: () => { state.autosaveCalls++; },
  toast: msg => state.messages.push(String(msg)),
  Number, Math,
});
// Make state values live as global bindings inside the VM context.
for (const [key, value] of Object.entries(state)) context[key] = value;
vm.runInContext(snippets.join('\n'), context, { timeout: 1000 });
context.toggleBeatPanel();
assert.equal(context.beatPanel.hidden, false, 'Beat panel should open');
context.generateBeatMarkers();
assert.deepEqual(Array.from(context.beatMarkers), [0, 0.5, 1, 1.5, 2, 2.5, 3], '120 BPM markers should have 0.5s spacing');
assert.equal(state.renderCalls, 1, 'timeline should rerender after generating markers');
context.addBeatMarker();
assert.ok(context.beatMarkers.some(t => Math.abs(t - 1.25) < 0.001), 'manual marker should use current playhead');
const countBeforeDuplicate = context.beatMarkers.length;
context.addBeatMarker();
assert.equal(context.beatMarkers.length, countBeforeDuplicate, 'duplicate manual marker should be ignored');
context.clearBeatMarkers();
assert.equal(context.beatMarkers.length, 0, 'clear action should remove all markers');
assert.ok(state.saveCalls >= 3 && state.autosaveCalls >= 3, 'changes should save/autosave');
console.log('PASS: Beat actions are exported and declared');
console.log('PASS: Beat panel opens, BPM grid spacing, manual marker, duplicate guard, clear and autosave');
