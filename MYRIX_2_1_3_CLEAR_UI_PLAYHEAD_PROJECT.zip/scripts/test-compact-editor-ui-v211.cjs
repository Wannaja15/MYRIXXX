const fs=require('fs');const p='app/src/main/assets/index.html';const s=fs.readFileSync(p,'utf8');
const checks=[
 ['compact tool dock exists',s.includes('id="compactToolDock"')],
 ['editor starts collapsed',s.includes('class="editor compact-collapsed" id="propertyEditor"')],
 ['eight quick tools',((s.match(/class="compact-tool"/g)||[]).length===8)],
 ['open compact panel action',s.includes('window.openCompactTool=function(page)')],
 ['close compact panel action',s.includes('window.closeCompactToolPanel=function()')],
 ['larger canvas rule',s.includes('height:min(43dvh,390px)!important')],
 ['compact dock CSS',s.includes('myrix-compact-am-layout-211')],
 ['cut tool opens media panel',s.includes("onclick=\"openCompactTool('media')\"><span class=\"compact-tool-icon\">✂</span><small>Potong / CUT</small>")]
];let bad=0;for(const [name,ok] of checks){console.log((ok?'PASS ':'FAIL ')+name);if(!ok)bad++;}if(bad)process.exit(1);
