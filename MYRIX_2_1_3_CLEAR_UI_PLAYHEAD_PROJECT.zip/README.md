# MYRIX 2.1.3 — Clear UI & Live Playhead

Pembaruan editor mobile MYRIX: menu alat berkontras tinggi dan lebih mudah dibaca, pembacaan waktu selalu diperbarui selama playback, playhead mengikuti timeline secara lebih konsisten, dan jam playback memakai timestamp monotonic agar tidak tertinggal saat frame terlambat. Fitur yang sudah ada—CUT/SPLIT, crop foto/video, keyframe, efek, Beat, X/Y/Z, autosave, dan proyek—tetap diperiksa oleh tes otomatis.

## Build APK dari HP
1. Unggah isi ZIP proyek ke root repository GitHub, termasuk `.github/workflows` dan `scripts`.
2. Buka tab **Actions** dan jalankan **MYRIX 2.1.3 — Clear UI & Live Playhead**.
3. Tunggu job validasi dan build selesai. Jika berhasil, buka **Artifacts** lalu unduh `MYRIX-debug-APK`.
4. Ekstrak artifact dan pasang `app-debug.apk` di HP.

Versi Android: `2.1.3` (`versionCode 11`). Build Gradle nyata harus dikonfirmasi melalui GitHub Actions; tes lokal tidak menggantikannya. Backup proyek/media sebelum memasang versi baru.
