package com.myrix.editor;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebResourceRequest;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1402;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean waitingForExitSave = false;
    private long exitSaveStartedAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) || "https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    if ("file".equals(uri.getScheme())) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    protected void onPause() {
        // Best-effort flush when Android backgrounds the app. Edits are also autosaved while editing.
        if (webView != null) {
            webView.evaluateJavascript(
                "try { if (window.MYRIX_SAVE_ON_EXIT) window.MYRIX_SAVE_ON_EXIT(); } catch (e) {}",
                null
            );
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        if (waitingForExitSave) return;
        waitingForExitSave = true;
        exitSaveStartedAt = SystemClock.uptimeMillis();
        // Evaluate a promise that marks completion only after IndexedDB/media writes finish.
        webView.evaluateJavascript(
            "window.__myrixExitSaveDone = false; " +
            "Promise.resolve().then(async function(){ " +
            " try { if (window.MYRIX_SAVE_ON_EXIT) await window.MYRIX_SAVE_ON_EXIT(); } catch (e) {} " +
            " window.__myrixExitSaveDone = true; " +
            "});",
            null
        );
        mainHandler.postDelayed(this::pollExitSaveAndFinish, 80);
    }

    private void pollExitSaveAndFinish() {
        if (isFinishing()) return;
        if (webView == null) {
            finish();
            return;
        }
        webView.evaluateJavascript("String(window.__myrixExitSaveDone === true)", value -> {
            if (isFinishing()) return;
            if ("\"true\"".equals(value) || "true".equals(value) ||
                SystemClock.uptimeMillis() - exitSaveStartedAt >= 10000L) {
                finish();
            } else {
                mainHandler.postDelayed(this::pollExitSaveAndFinish, 100);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
