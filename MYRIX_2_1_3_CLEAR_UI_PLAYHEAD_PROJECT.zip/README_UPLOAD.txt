MYRIX 2.1.3 — CARA UPLOAD DARI HP DAN BUILD APK

1. Unduh dan ekstrak MYRIX_2_1_3_CLEAR_UI_PLAYHEAD_PROJECT.zip.
2. Upload ISI folder proyek ke root repository GitHub, termasuk folder .github/workflows dan scripts.
3. Pastikan .github/workflows/build-apk.yml ikut ter-upload dan workflow lama telah diganti.
4. Buka tab Actions dan jalankan “MYRIX 2.1.3 — Clear UI & Live Playhead”.
5. Tunggu validasi dan build selesai. Jika berhasil, buka run yang hijau → Artifacts → unduh MYRIX-debug-APK.
6. Ekstrak artifact dan instal app-debug.apk.

APK belum dianggap terbangun sampai GitHub Actions selesai sukses dan artifact muncul. Jangan unggah APK lama sebagai pengganti proyek sumber. Versi Android 2.1.3, versionCode 11. Backup proyek dan media sebelum update.
