# MYRIX 2.1.6 — Full Audit, Launcher Logo & Workflow Fix

MYRIX is a mobile-first HTML/JavaScript video editor packaged as an Android WebView application.

## Release 2.1.6
- Android app version: `2.1.6`, `versionCode 14`.
- Kept the existing MYRIX logo artwork in the HTML splash/home/editor header and in Android launcher resources.
- Added legacy launcher icon PNGs for all density buckets plus Android 8+ adaptive icon resources for normal and round launcher icons.
- The validator now checks icon declarations, PNG signatures/dimensions, adaptive icon XML, package ID, HTML asset paths, and version consistency.
- Workflow prefers the canonical `MYRIX_2_1_6_RELEASE.zip` over an older Android project in the repository root. This prevents older source files from silently replacing the latest logo or features during build.
- Workflow does not invoke `android-actions/setup-android@v3`, avoiding its obsolete `tools` package request seen in earlier failed runs.
- Workflow checks source version, runs every `scripts/test*.cjs` regression test, builds the debug APK, checks APK metadata/icon declarations with `aapt`, and uploads the APK plus SHA-256 checksum.
- Kept features for effects, Beat, motion/keyframes, X/Y/Z transform, crop, cut/split, autosave, shape editor, compact editing UI and live playhead.

## Build from a phone
1. Replace the repository workflow at `.github/workflows/build-apk.yml` with the workflow included in this source package.
2. Upload `MYRIX_2_1_6_RELEASE.zip` to the repository root. The archive contains the complete project and its own matching workflow; the repository workflow must still be committed separately before it can run.
3. Open GitHub Actions and run **MYRIX 2.1.6 - Full Audit Build**.
4. After a green run, download artifact `MYRIX-2.1.6-debug-APK`. It contains the debug APK and `SHA256SUMS.txt`.

## Source of truth
- HTML for standalone testing: `MYRIX_2_1_6_RELEASE.html`.
- Android WebView HTML: `app/src/main/assets/index.html` (must be byte-identical to standalone HTML).
- Android launcher icon: `app/src/main/res/mipmap-*` and `app/src/main/res/mipmap-anydpi-v26/`.
- Workflow: `.github/workflows/build-apk.yml`.

## Verification status
Static validator and all regression-test scripts are run for this release. Earlier browser runtime testing confirmed the playhead advances and responds to seek/pause/resume. A new real GitHub build and launcher-icon check on the target phone still require running the workflow and installing its artifact; the ZIP by itself is not a built APK.
