const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const gradle = fs.readFileSync('app/build.gradle', 'utf8');

assert.match(html, /function syncAudioPlayback\(seekWhenPaused=false,force=false\)\s*\{/,
  'the app must define the audio synchronizer called by Play/Pause');
assert.match(html, /syncAudioPlayback\(\);syncVideoPlayback\(false,false\);raf=requestAnimationFrame\(tick\)/,
  'Play must reach RAF scheduling after synchronizing media');
assert.match(html, /name="application-version" content="2\.1\.6"/);
assert.match(gradle, /versionName\s+'2\.1\.6'/);

const start = html.indexOf('function syncAudioPlayback(seekWhenPaused=false,force=false){');
const end = html.indexOf('\nfunction syncVideoPlayback(', start);
assert(start >= 0 && end > start, 'audio synchronizer source must be extractable');
const source = html.slice(start, end);
let clock = 1000;
const audio = {
  currentTime: 0, duration: 20, readyState: 1, paused: true,
  seeking: false, error: null, volume: 1, playCount: 0, pauseCount: 0,
  play() { this.playCount++; this.paused = false; return Promise.resolve(); },
  pause() { this.pauseCount++; this.paused = true; },
};
const item = {
  type: 'audio', audioEl: audio, _timelineStart: 0, _timelineEnd: 5,
  trimIn: 2, trimOut: null, volume: 100, fadeIn: 0, fadeOut: 0,
};
const state = {
  performance: { now: () => clock },
  items: [item], time: 0, playing: true,
  sourceTimeAt(d, t) { return (Number(d.trimIn) || 0) + (t - (Number(d._timelineStart) || 0)); },
  itemTimelineStart(d) { return Number(d._timelineStart) || 0; },
  itemTimelineEnd(d) { return Number.isFinite(d._timelineEnd) ? d._timelineEnd : 10; },
  setMediaElementVolume(d, t) { d.audioEl.volume = Math.max(0, Math.min(1, (d.volume || 0) / 100)); },
  toast(message) { state.messages.push(message); },
  messages: [], console, Math, Number, Promise,
};
const context = vm.createContext(state);
vm.runInContext(source, context, { timeout: 1000 });
context.syncAudioPlayback();
assert.equal(audio.playCount, 1, 'active audio should start when playback begins');
assert.equal(audio.paused, false, 'active audio should be playing');
assert.equal(audio.currentTime, 2, 'trimmed audio starts at trimIn when timeline starts at zero');
assert.equal(item._audioWasActive, true, 'active state should be remembered to avoid repeated seeks');

// A forced scrub should synchronize the audio source position to the timeline.
context.time = 1;
clock += 100;
context.syncAudioPlayback(false, true);
assert.equal(audio.currentTime, 3, 'forced timeline seek should map to trimIn + elapsed timeline time');

// Audio must pause when the timeline has passed the clip end.
context.time = 5;
clock += 100;
context.syncAudioPlayback();
assert.equal(audio.paused, true, 'audio outside its clip range should pause');
assert.equal(item._audioWasActive, false, 'inactive audio should clear active state');

// Also check the concrete UI update routine and clock source are still in the same delivered build.
assert.match(html, /function updatePlayhead\(\)\{/);
assert.match(html, /playbackBaseTime\+Math\.max\(0,\(ts-playbackStartTs\)\/1000\)/);
assert.match(html, /p\.style\.setProperty\('left',x\+'px'\)/);
console.log('PASS: audio synchronizer is defined; active audio starts at trimIn, forced seek follows playhead, out-of-range audio pauses');
console.log('PASS: playhead updates absolute timeline position from RAF playback clock');
