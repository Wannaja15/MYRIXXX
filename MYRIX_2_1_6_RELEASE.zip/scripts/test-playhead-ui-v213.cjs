const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const gradle = fs.readFileSync('app/build.gradle', 'utf8');
const checks = [
  ['version 2.1.6 metadata', html.includes('name="application-version" content="2.1.6"')],
  ['high-contrast menu style', html.includes('myrix-2-1-5-visible-playhead') && html.includes('color:#f1f5ff!important')],
  ['larger readable menu labels', html.includes('font-size:10px!important;line-height:1.18!important;font-weight:750!important')],
  ['high-visibility time display', html.includes('#editorApp .timebar #timeText') && html.includes("label.setAttribute('aria-label','Waktu '+shown.toFixed(2)+' detik')")],
  ['playhead uses absolute time coordinate', /p\.style\.setProperty\('left',x\+'px'\)/.test(html) && /p\.style\.setProperty\('transform','none'\)/.test(html)],
  ['playhead line crosses ruler and tracks', /p\.style\.setProperty\('top','0px'\)/.test(html) && /RULER_H\+Math\.max\(MIN_LAYERS,layerCount\)\*TRACK_H/.test(html)],
  ['playback follows timeline near right edge, not at 58%', /const threshold=width\*\.92/.test(html) && /x-width\*\.75/.test(html)],
  ['paused scrubbing keeps playhead visible', /When the user scrubs or taps a distant time while paused, keep the marker visible/.test(html)],
  ['playback clock uses RAF timestamp', html.includes('playbackBaseTime+Math.max(0,(ts-playbackStartTs)/1000)')],
  ['every RAF updates time and playhead', /\$\('timeSlider'\)\.value=String\(time\);updatePlayhead\(\);/.test(html)],
  ['project version and android code are updated', /versionCode\s+14/.test(gradle) && /versionName\s+'2\.1\.6'/.test(gradle)],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);

// Exercise the real updatePlayhead() and tick() functions in a deterministic mock DOM.
const updateStart = html.indexOf('function updatePlayhead(){');
const updateEnd = html.indexOf('\nfunction updateKeySelection()', updateStart);
const tickStart = html.indexOf('function tick(ts){');
const tickEnd = html.indexOf('\n\nfunction toggleGrid()', tickStart);
assert(updateStart >= 0 && updateEnd > updateStart, 'updatePlayhead source must be extractable');
assert(tickStart >= 0 && tickEnd > tickStart, 'tick source must be extractable');
const elements = Object.create(null);
const mock$ = id => elements[id] || (elements[id] = {
  value: '0', textContent: '', style: { setProperty(k,v) { this[k] = v; } }, clientWidth: 800, scrollLeft: 0,
  setAttribute() {},
});
const state = {
  items: [], selected: null, time: 0, playing: true, raf: 0,
  playbackStartTs: null, playbackBaseTime: 0, lastTs: 0,
  lastRenderTs: 0, lastVideoSyncTs: 0, DURATION: 20,
  PX_PER_SEC: 82, LABEL_W: 78, RULER_H: 26, TRACK_H: 38,
  MIN_LAYERS: 1, layerCount: 1, tracks: {appendChild(el) { elements[el.id] = el; }},
  requestAnimationFrame() { return 7; }, cancelAnimationFrame() {},
  render() {}, pauseAllMedia() {}, updatePlayButton() {},
  syncAudioPlayback() {}, syncVideoPlayback() {}, $: mock$,
  Math, Number, String, document: { createElement() { return {id:'',className:'',style:{setProperty(k,v){this[k]=v;}}}; } },
};
const ctx = vm.createContext(state);
vm.runInContext(html.slice(updateStart, updateEnd) + '\n' + html.slice(tickStart, tickEnd), ctx, {timeout: 1000});
ctx.tick(1000); // establishes RAF playback origin
ctx.tick(2000); // one second elapsed
assert.ok(Math.abs(ctx.time - 1) < 0.001, 'playback clock should advance by elapsed RAF time');
assert.equal(mock$('timeSlider').value, '1', 'time slider should be updated during playback');
assert.equal(mock$('timeText').textContent, '00:01.00', 'visible seconds counter should update during playback');
assert.equal(mock$('playline').style.left, '160px', 'playhead left coordinate equals label gutter + 1 second * pixels/second');
assert.equal(mock$('playline').style.transform, 'none', 'playhead is positioned by left, not a transform that may be visually masked');
assert.equal(mock$('playline').style.top, '0px', 'playhead starts over the ruler');
assert.equal(mock$('playline').style.height, '64px', 'playhead spans ruler and layer track');
assert.equal(mock$('timelineScroller').scrollLeft, 0, 'playhead should visibly move without following too early');
ctx.time = 8.2;
ctx.playbackBaseTime = 8.2;
ctx.updatePlayhead();
assert.ok(mock$('timelineScroller').scrollLeft > 0, 'timeline follows only when playhead approaches the right edge');
assert.ok(Math.abs((750.4 - mock$('timelineScroller').scrollLeft) - 600) < 2, 'auto-follow moves marker to the chosen viewport target');
ctx.playing = false;
ctx.time = 18;
ctx.updatePlayhead();
const visibleAfterSeek = 78 + 18*82 - mock$('timelineScroller').scrollLeft;
assert.ok(visibleAfterSeek >= 0 && visibleAfterSeek <= 800, 'paused scrubbing auto-reveals the playhead inside the viewport');
ctx.time = 0;
ctx.updatePlayhead();
assert.equal(mock$('timelineScroller').scrollLeft, 0, 'seeking back to zero reveals the start of timeline');
console.log('PASS: real playhead/tick functions move line by absolute timeline time, span ruler, defer auto-follow, and reveal manually-scrubbed times');
