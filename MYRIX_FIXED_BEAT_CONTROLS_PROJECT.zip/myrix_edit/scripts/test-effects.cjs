#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const file = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(file, 'utf8');
function between(start, end) {
  const a = html.indexOf(start);
  const b = html.indexOf(end, a + start.length);
  if (a < 0 || b < 0) throw new Error(`Tidak dapat menemukan rentang ${start} -> ${end}`);
  return html.slice(a, b);
}
const definitions = between('const FX_EFFECTS=', 'const FX_EXTRA_CATEGORIES=');
const core = between('function clampNumber(value', 'function normalizeCurve(');
const helpers = between('function effectPhase(', 'function syncZ()');
const exportOverlay = between('function drawExportFxOverlays(', 'function drawExportFrame(');
const testCode = `
const DURATION = 10; let time = 1;
const FX_OVERLAY_KEYS = ['flash','lightLeak','lensFlare','grain','scanlines','halftone','vhsTrack'];
let fxNoiseDataUrl = null, fxNoiseCanvas = null, fxPatternCache = {};
const overlayNodes = [];
function makeCanvasContext() {
  return { createImageData(w,h){return {data:new Uint8ClampedArray(w*h*4)};}, putImageData(){}, clearRect(){}, fillRect(){}, drawImage(){}, beginPath(){}, arc(){}, fill(){}, save(){}, restore(){},
    createPattern(){return {};}, createRadialGradient(){return {addColorStop(){}};}, createLinearGradient(){return {addColorStop(){}};} };
}
const document = { createElement(tag) { return {tagName:tag,style:{},dataset:{},width:0,height:0,offsetWidth:100,offsetHeight:80,setAttribute(){},getContext(){return makeCanvasContext();},toDataURL(){return 'data:image/png;base64,';},remove(){this.removed=true;}}; } };
const scene = { clientWidth:320, clientHeight:568, appendChild(node){overlayNodes.push(node);node.parentElement=this;return node;} };
function getComputedStyle(el) { return {borderRadius:el?.style?.borderRadius || '0px'}; }
function itemIsActiveAt(){return true;}
function $(id) { return id === 'scene' ? scene : null; }
function state(d,t) { return {x:t*7,y:t*3,s:1+t*.1,r:t*0,o:1,shake:0}; }
${definitions}
${core}
${helpers}
${exportOverlay}
const keys = FX_EFFECTS.map(v => v[0]);
if (new Set(keys).size !== keys.length) throw new Error('Ada kunci FX_EFFECTS duplikat');
if (keys.length < 60) throw new Error('Katalog terlalu kecil: ' + keys.length);
const unknownSchema = Object.keys(FX_PARAM_SCHEMA).filter(k => !keys.includes(k));
if (unknownSchema.length) throw new Error('Schema tanpa efek: ' + unknownSchema.join(','));
const result = [];
for (const [key, label] of FX_EFFECTS) {
  const base = {power:100,levels:{},speeds:{},params:{},[key]:true};
  if (key === 'blur') base.blur = 3;
  const d = {id:7,x:0,y:0,s:1,r:0,o:1,shake:0,keys:[],fx:normalizeFx(base)};
  const css = filterString(d, 1.25, 2);
  const bal = (css.match(/\\(/g)||[]).length - (css.match(/\\)/g)||[]).length;
  if (typeof css !== 'string' || !css || /NaN|undefined|Infinity/.test(css) || bal !== 0)
    throw new Error(label + ' menghasilkan filter tidak valid: ' + css);
  const anim = effectAnimation(d, 1.25);
  if (![anim.scale, anim.rotation, anim.opacity, effectPulseBrightness(d,1.25)].every(Number.isFinite))
    throw new Error(label + ' menghasilkan nilai animasi non-finite');
  if (['motionBlur','directionalBlur','trail'].includes(key)) {
    const filters = motionSmearFilters(d,1.25,1,key);
    if (!Array.isArray(filters) || filters.some(x => /NaN|undefined|Infinity/.test(x))) throw new Error(label + ' menghasilkan smear tidak valid');
  }
  result.push(key);
  // Exercise parameter boundaries at both ends; any active effect must still return sane values.
  const defs = FX_PARAM_SCHEMA[key] || [];
  for (const side of ['min','max']) {
    const params = {};
    for (const [param, label, min, max] of defs) params[param] = side === 'min' ? min : max;
    const edgeFx = {power:side === 'min' ? 0 : 200,[key]:true,levels:{[key]:side === 'min' ? 0 : 200},speeds:{[key]:side === 'min' ? 25 : 300},params:{[key]:params}};
    if (key === 'blur') edgeFx.blur = side === 'min' ? 0 : 12;
    const edgeD = {id:11,x:0,y:0,s:1,r:0,o:1,shake:0,keys:[],fx:normalizeFx(edgeFx)};
    const edgeCss = filterString(edgeD, 2.75, 3);
    if (typeof edgeCss !== 'string' || /NaN|undefined|Infinity/.test(edgeCss) || edgeCss.split('(').length !== edgeCss.split(')').length)
      throw new Error(label + ' gagal pada batas ' + side + ': ' + edgeCss);
    const edgeAnim = effectAnimation(edgeD, 2.75);
    if (![edgeAnim.scale,edgeAnim.rotation,edgeAnim.opacity].every(Number.isFinite)) throw new Error(label + ' animasi gagal pada batas ' + side);
  }
}
// Exercise every DOM overlay and its Canvas export counterpart with a small mock context.
for (const key of FX_OVERLAY_KEYS) {
  const fx = normalizeFx({[key]:true,levels:{[key]:100},params:{}});
  const el = {style:{left:'50%',top:'50%',width:'100px',height:'80px',transform:'translate(-50%,-50%)',visibility:'visible',borderRadius:'0px'},offsetWidth:100,offsetHeight:80};
  const d = {id:31,type:'image',el,fx};
  syncFxOverlays(d,1.25,.8);
  if (!d._fxOverlays?.[key] || d._fxOverlays[key].style.display !== 'block') throw new Error(key + ' overlay preview tidak aktif');
  drawExportFxOverlays(makeCanvasContext(),d,1.25,100,80,.8,1);
  removeFxOverlays(d);
}
const restored = normalizeFx({power:80,blur:4,glow:true,levels:{glow:80},speeds:{glitch:130},params:{glow:{radius:44}}});
if (restored.glow !== true || restored.blur !== 4 || restored.levels.glow !== 80 || restored.speeds.glitch !== 130 || restored.params.glow.radius !== 44)
  throw new Error('Migrasi pengaturan proyek lama gagal');
if (restored.motionBlur !== false || restored.cinema !== false) throw new Error('Efek baru harus nonaktif pada proyek lama');
const clamps = normalizeFx({params:{blur:{radius:999},posterize:{levels:-10}},levels:{blur:999},speeds:{flash:999}});
if (clamps.params.blur.radius !== 12 || clamps.params.posterize.levels !== 2 || clamps.levels.blur !== 200 || clamps.speeds.flash !== 300)
  throw new Error('Batas parameter tidak dijaga');
console.log('PASS: ' + result.length + ' efek lolos pemeriksaan filter/animasi');
console.log('PASS: semua overlay punya jalur preview dan Canvas export yang berjalan di mock test');
console.log('PASS: migrasi data proyek lama dan default efek baru');
console.log('PASS: batas intensitas, kecepatan, dan parameter');
`;
try {
  new vm.Script(testCode, { filename: 'myrix-effects-test.js' });
  vm.runInNewContext(testCode, { console, Math, Number, Object, Array, String, Set, JSON, Map, Date }, { timeout: 3000 });
} catch (error) {
  console.error('FAIL:', error && error.stack || error);
  process.exitCode = 1;
}
