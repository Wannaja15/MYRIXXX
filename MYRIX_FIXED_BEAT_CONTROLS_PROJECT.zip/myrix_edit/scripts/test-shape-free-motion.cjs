#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');
const types = ['rectangle','rounded','circle','triangle','diamond','star','pentagon','hexagon','octagon','parallelogram','trapezoid','arrow','cross','heart','ring','line'];
assert.match(html, /id="shapePickerModal"/);
assert.match(html, /id="shapeColorInput"/);
for (const type of types) assert.match(html, new RegExp(`createShape\\('${type}'\\)`), `shape picker missing ${type}`);
assert.match(html, /window\.createShape=createShape;/, 'shape action must be exposed for inline handlers');
assert.match(html, /shapeType:d\.shapeType\|\|'rectangle',shapeColor:d\.shapeColor\|\|'#ffffff'/, 'shape metadata must be saved with project snapshots');
assert.match(html, /applyShapeStyle\(el,x\.shapeType,x\.shapeColor\)/, 'shape metadata must be restored');
assert.match(html, /drawShapeGeometry\(drawCtx,d\.shapeType\|\|'rectangle',baseW,baseH,radius\)/, 'export should draw shape geometry');
assert.match(html, /p\.style\.transform='translate3d\('\+\(time\*PX_PER_SEC\)/, 'playhead should move via GPU-friendly transform');
assert.match(html, /\$\('timeSlider'\)\.value=time;updatePlayhead\(\);if\(ts-lastRenderTs>=33\)/, 'playhead position must update on each animation frame');
assert.match(html, /Math\.max\(-10000,Math\.min\(10000,nx\)\)/, 'object drag should not clamp positions to canvas bounds');

const normKeyStart = html.indexOf('function normalizeKey(k){');
const normKeyEnd = html.indexOf('\nfunction normalizeItem(', normKeyStart);
assert.ok(normKeyStart >= 0 && normKeyEnd > normKeyStart, 'normalizeKey function not found');
const normalizeKeySrc = html.slice(normKeyStart, normKeyEnd);
const keyContext = vm.createContext({ DURATION: 120, normalizeCurve: c => c || {x1:.333,y1:0,x2:.667,y2:1}, Math, Number, Object });
vm.runInContext(normalizeKeySrc, keyContext, {timeout:1000});
const key = keyContext.normalizeKey({t:1,x:1200,y:-3200,s:1,r:0,o:1,shake:0});
assert.equal(key.x, 1200, 'positive off-canvas keyframe position should be retained');
assert.equal(key.y, -3200, 'negative off-canvas keyframe position should be retained');

const normItemStart = html.indexOf('function normalizeItem(x){');
const normItemEnd = html.indexOf('\nfunction snapshot()', normItemStart);
assert.ok(normItemStart >= 0 && normItemEnd > normItemStart, 'normalizeItem function not found');
const normalizeItemSrc = html.slice(normItemStart, normItemEnd);
const itemContext = vm.createContext({ nextId:1, DURATION:120, MAX_LAYERS:50, SHAPE_TYPES:new Set(types), normalizeFx:()=>({}), normalizeKey:k=>k, Math, Number, Object, Array, String });
vm.runInContext(normalizeItemSrc, itemContext, {timeout:1000});
const item = itemContext.normalizeItem({id:9,type:'shape',shapeType:'star',shapeColor:'#e149ff',x:1500,y:-2400});
assert.equal(item.shapeType,'star');
assert.equal(item.shapeColor,'#e149ff');
assert.equal(item.x,1500);
assert.equal(item.y,-2400);

// Exercise every export path type with a recorder context so malformed geometry fails the test.
const helperStart = html.indexOf(' function drawShapeGeometry(ctx,type,w,h,radius){');
const helperEnd = html.indexOf('\n function drawExportFrame', helperStart);
assert.ok(helperStart >= 0 && helperEnd > helperStart, 'shape export renderer not found');
const geometrySource = html.slice(helperStart, helperEnd);
const recorder = new Proxy({}, {get(target, name) { if (!(name in target)) target[name]=()=>{}; return target[name]; }});
const geometryContext = vm.createContext({roundedRect:()=>{},Math});
vm.runInContext(geometrySource + '\nthis.drawShapeGeometry=drawShapeGeometry;', geometryContext, {timeout:1000});
for (const type of types) assert.doesNotThrow(()=>geometryContext.drawShapeGeometry(recorder,type,120,100,8), `export geometry failed for ${type}`);

console.log(`PASS: shape picker and ${types.length} shape types are available`);
console.log('PASS: shape type/color persist through project snapshots and restore');
console.log('PASS: off-canvas coordinates are preserved in object/keyframe normalization');
console.log('PASS: shape export renderer handles every shape type');
console.log('PASS: playhead updates each animation frame');
