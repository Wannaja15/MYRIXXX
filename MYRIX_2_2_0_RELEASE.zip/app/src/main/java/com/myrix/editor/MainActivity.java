package com.myrix.editor;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1402;
    private static final int STORAGE_PERMISSION_REQUEST = 1403;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean waitingForExitSave = false;
    private long exitSaveStartedAt = 0L;
    private final ArrayDeque<SaveRequest> pendingSaves = new ArrayDeque<>();
    private boolean storagePermissionRequested = false;

    private static final class SaveRequest {
        final String filename;
        final String mime;
        final byte[] bytes;
        final boolean video;
        SaveRequest(String filename, String mime, byte[] bytes, boolean video) {
            this.filename = filename;
            this.mime = mime;
            this.bytes = bytes;
            this.video = video;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new MyrixFileBridge(), "JJAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) || "https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    if ("file".equals(uri.getScheme())) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class MyrixFileBridge {
        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64Data) {
            enqueueSave(filename, mimeType, base64Data, false);
        }

        // Saves video to both Movies/MYRIX (Gallery) and Download/MYRIX.
        @JavascriptInterface
        public void saveVideoToGallery(String filename, String mimeType, String base64Data) {
            enqueueSave(filename, mimeType, base64Data, true);
        }
    }

    private void enqueueSave(String filename, String mimeType, String base64Data, boolean video) {
        try {
            String safeName = safeFileName(filename, video ? "myrix-video.mp4" : "myrix-file.bin");
            String safeMime = (mimeType == null || mimeType.trim().isEmpty())
                    ? (video ? "video/mp4" : "application/octet-stream") : mimeType.trim();
            byte[] bytes = Base64.decode(base64Data == null ? "" : base64Data, Base64.DEFAULT);
            if (bytes.length == 0) {
                showToast("File kosong, tidak disimpan.");
                return;
            }
            SaveRequest request = new SaveRequest(safeName, safeMime, bytes, video);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                synchronized (pendingSaves) { pendingSaves.add(request); }
                requestStoragePermission();
                return;
            }
            saveRequest(request);
        } catch (Exception error) {
            android.util.Log.e("MYRIX", "Unable to prepare file save", error);
            showToast("File gagal disiapkan untuk disimpan.");
        }
    }

    private String safeFileName(String input, String fallback) {
        String name = input == null ? "" : input.replace('\\', '/');
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        name = name.replaceAll("[^A-Za-z0-9._() -]", "_").trim();
        if (name.isEmpty() || ".".equals(name) || "..".equals(name)) name = fallback;
        if (name.length() > 120) {
            int dot = name.lastIndexOf('.');
            String ext = dot > 0 ? name.substring(dot) : "";
            name = name.substring(0, Math.max(1, 120 - ext.length())) + ext;
        }
        return name;
    }

    private void requestStoragePermission() {
        if (storagePermissionRequested) return;
        storagePermissionRequested = true;
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
            } else {
                storagePermissionRequested = false;
                flushPendingSaves(true);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_REQUEST) {
            storagePermissionRequested = false;
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            flushPendingSaves(granted);
        }
    }

    private void flushPendingSaves(boolean granted) {
        ArrayDeque<SaveRequest> copy = new ArrayDeque<>();
        synchronized (pendingSaves) {
            while (!pendingSaves.isEmpty()) copy.add(pendingSaves.remove());
        }
        if (!granted) {
            showToast("Izin penyimpanan ditolak. Izinkan akses penyimpanan agar unduhan bisa disimpan.");
            return;
        }
        for (SaveRequest request : copy) saveRequest(request);
    }

    private void saveRequest(SaveRequest request) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (request.video) {
                    Uri galleryUri = insertMediaStore(request, true);
                    if (galleryUri == null) throw new IOException("Gallery URI unavailable");
                    boolean downloadSaved = false;
                    try {
                        downloadSaved = insertMediaStore(request, false) != null;
                    } catch (Exception downloadError) {
                        android.util.Log.e("MYRIX", "Gallery saved but Downloads copy failed", downloadError);
                    }
                    showToast(downloadSaved
                            ? "Video disimpan ke Galeri dan Download/MYRIX."
                            : "Video disimpan ke Galeri, tetapi salinan Download gagal.");
                } else {
                    insertMediaStore(request, false);
                    showToast("File disimpan ke Download/MYRIX.");
                }
            } else {
                saveLegacy(request);
                showToast(request.video ? "Video disimpan ke Movies/MYRIX dan Download/MYRIX." : "File disimpan ke Download/MYRIX.");
            }
        } catch (Exception error) {
            android.util.Log.e("MYRIX", "Saving file failed", error);
            showToast("Gagal menyimpan file. Periksa ruang perangkat dan izin penyimpanan.");
        }
    }

    private Uri insertMediaStore(SaveRequest request, boolean gallery) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, request.filename);
        values.put(MediaStore.MediaColumns.MIME_TYPE, request.mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, gallery
                ? Environment.DIRECTORY_MOVIES + "/MYRIX"
                : Environment.DIRECTORY_DOWNLOADS + "/MYRIX");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri collection = gallery ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        Uri uri = getContentResolver().insert(collection, values);
        if (uri == null) throw new IOException("MediaStore insert returned null");
        try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("Output stream unavailable");
            output.write(request.bytes);
            output.flush();
        } catch (Exception writeError) {
            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            if (writeError instanceof IOException) throw (IOException) writeError;
            throw new IOException("Could not write to MediaStore", writeError);
        }
        ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(uri, ready, null, null);
        return uri;
    }

    @SuppressWarnings("deprecation")
    private void saveLegacy(SaveRequest request) throws IOException {
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MYRIX");
        writePublicFile(downloadDir, request.filename, request.bytes);
        if (request.video) {
            File movieDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "MYRIX");
            File videoFile = writePublicFile(movieDir, request.filename, request.bytes);
            MediaScannerConnection.scanFile(this, new String[]{videoFile.getAbsolutePath()}, new String[]{request.mime}, null);
        }
        MediaScannerConnection.scanFile(this, new String[]{new File(downloadDir, request.filename).getAbsolutePath()}, new String[]{request.mime}, null);
    }

    private File writePublicFile(File directory, String filename, byte[] data) throws IOException {
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Unable to create directory " + directory);
        File target = new File(directory, filename);
        try (FileOutputStream output = new FileOutputStream(target, false)) {
            output.write(data);
            output.flush();
            output.getFD().sync();
        }
        return target;
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    protected void onPause() {
        // Best-effort flush when Android backgrounds the app. Edits are also autosaved while editing.
        if (webView != null) {
            webView.evaluateJavascript(
                "try { if (window.MYRIX_SAVE_ON_EXIT) window.MYRIX_SAVE_ON_EXIT(); } catch (e) {}",
                null
            );
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        if (waitingForExitSave) return;
        waitingForExitSave = true;
        exitSaveStartedAt = SystemClock.uptimeMillis();
        webView.evaluateJavascript(
            "window.__myrixExitSaveDone = false; " +
            "Promise.resolve().then(async function(){ " +
            " try { if (window.MYRIX_SAVE_ON_EXIT) await window.MYRIX_SAVE_ON_EXIT(); } catch (e) {} " +
            " window.__myrixExitSaveDone = true; " +
            "});",
            null
        );
        mainHandler.postDelayed(this::pollExitSaveAndFinish, 80);
    }

    private void pollExitSaveAndFinish() {
        if (isFinishing()) return;
        if (webView == null) {
            finish();
            return;
        }
        webView.evaluateJavascript("String(window.__myrixExitSaveDone === true)", value -> {
            if (isFinishing()) return;
            if ("\"true\"".equals(value) || "true".equals(value) ||
                SystemClock.uptimeMillis() - exitSaveStartedAt >= 10000L) {
                finish();
            } else {
                mainHandler.postDelayed(this::pollExitSaveAndFinish, 100);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
