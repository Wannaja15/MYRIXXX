MYRIX 2.1.6 — PANDUAN UPLOAD DARI HP DAN BUILD APK

PENTING: untuk mencegah proyek lama dipilih, upload file persis bernama MYRIX_2_1_6_RELEASE.zip ke root repository.

1. Ganti isi .github/workflows/build-apk.yml di repository menggunakan file workflow yang disertakan dalam paket ini. Commit perubahan workflow.
2. Upload MYRIX_2_1_6_RELEASE.zip ke halaman utama repository.
3. Buka Actions dan jalankan “MYRIX 2.1.6 - Full Audit Build”.
4. Workflow akan memilih ZIP versi ini lebih dahulu, memvalidasi ikon, menjalankan semua tes, lalu membuat debug APK.
5. Jika semua job hijau, buka Artifacts dan unduh MYRIX-2.1.6-debug-APK.
6. Ekstrak artifact dan instal MYRIX-2.1.6-debug.apk.

Jika workflow merah, kirim screenshot langkah merah terbaru. Jangan menganggap APK berhasil dibuat sebelum artifact muncul. Update di atas memakai versionCode 14; jika Android menolak instalasi di atas APK lama, simpan/backup proyek lebih dahulu karena APK debug mungkin ditandatangani dengan kunci berbeda.
