'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const html = read('app/src/main/assets/index.html');
const standalone = fs.readFileSync(path.join(root, 'MYRIX_2_2_0_RELEASE.html'));
const packaged = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'));
const gradle = read('app/build.gradle');
const manifest = read('app/src/main/AndroidManifest.xml');
const workflow = read('.github/workflows/build-apk.yml');

assert.match(html, /name="application-version" content="2\.2\.0"/);
assert.match(html, /class="versionTag">v2\.2\.0<\/em>/);
assert.match(gradle, /versionName\s+'2\.2\.0'/);
assert.match(gradle, /versionCode\s+15/);
assert.deepEqual(standalone, packaged, 'standalone HTML must be identical to APK HTML');
assert.match(manifest, /android:icon="@mipmap\/ic_launcher"/);
assert.match(manifest, /android:roundIcon="@mipmap\/ic_launcher_round"/);
assert.match(manifest, /android:label="MYRIX"/);
assert.match(html, /class="splash-mark"[\s\S]{0,250}data:image\/webp;base64,/);

const expectedSizes = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
for (const [density, size] of Object.entries(expectedSizes)) {
  for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const p = path.join(root, 'app/src/main/res', `mipmap-${density}`, name);
    const data = fs.readFileSync(p);
    assert.equal(data.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${p} should be a valid PNG`);
    assert.equal(data.readUInt32BE(16), size, `${p} width`);
    assert.equal(data.readUInt32BE(20), size, `${p} height`);
  }
}
const foreground = fs.readFileSync(path.join(root, 'app/src/main/res/drawable-nodpi/ic_launcher_foreground.png'));
assert.equal(foreground.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', 'adaptive launcher foreground should be PNG');
assert.equal(foreground.readUInt32BE(16), 432, 'adaptive launcher foreground width');
assert.equal(foreground.readUInt32BE(20), 432, 'adaptive launcher foreground height');

for (const icon of [
  'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
  'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
  'app/src/main/res/drawable-nodpi/ic_launcher_foreground.png',
  'app/src/main/res/values/colors.xml',
]) assert.ok(fs.existsSync(path.join(root, icon)), `${icon} exists`);

assert.match(workflow, /MYRIX_2_2_0_RELEASE\.zip/);
assert.match(workflow, /Prefer the explicitly named release ZIP/i);
assert.ok(workflow.indexOf('if [[ -f "$RELEASE_ZIP" ]]') < workflow.indexOf('if ! locate_project "$ROOT"'),
  'canonical release ZIP must be checked before repository-root project source');
assert.doesNotMatch(workflow, /android-actions\/setup-android@v3/);
assert.doesNotMatch(workflow, /cache:\s*gradle/, 'setup-java must not search for Gradle files before source preparation');
assert.match(workflow, /'platform-tools'[\s\S]*'platforms;android-35'[\s\S]*'build-tools;35\.0\.0'/);
assert.match(workflow, /versionName[\s\S]{0,80}2\\?\.2\\?\.0/);
assert.match(workflow, /MYRIX-2\.2\.0-debug-APK/);

console.log('PASS: version 2.2.0 / Android versionCode 15 is consistent');
console.log('PASS: standalone HTML matches Android asset byte-for-byte');
console.log('PASS: app label and normal/round/adaptive launcher logo resources are present');
console.log('PASS: workflow prioritizes the canonical release ZIP over stale repo files');
console.log('PASS: workflow avoids the obsolete setup-android tools package and Java Gradle-cache ordering');
console.log('PASS: workflow installs needed SDK packages and checks APK metadata after build');
