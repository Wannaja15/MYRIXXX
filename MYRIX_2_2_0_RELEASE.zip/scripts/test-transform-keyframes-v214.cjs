const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const gradle = fs.readFileSync('app/build.gradle', 'utf8');
assert.match(html, /application-version" content="2\.2\.0/);
assert.match(gradle, /versionCode\s+15/);
assert.match(gradle, /versionName\s+'2\.2\.0'/);
assert.match(html, /function syncAnimatedTransformReadouts\(\)/, 'transform fields must update as the playhead moves');
assert.match(html, /syncZ\(\);syncAnimatedTransformReadouts\(\)/, 'render must update the animated transform readouts and Z stacking');
assert.match(html, /sort\(\(a,b\)=>\(\(Number\(worldState\(a\.d,t\)\.z\)\|\|0\)-\(Number\(worldState\(b\.d,t\)\.z\)\|\|0\)\)/, 'export ordering must follow animated Z');

const normStart = html.indexOf('function normalizeCurve(');
const normEnd = html.indexOf('\nlet cropMode', normStart);
const easingStart = html.indexOf('function cubicBezierAt(');
const easingEnd = html.indexOf('\nfunction keyIndexAt(', easingStart);
const keyStart = easingEnd + 1;
const keyEnd = html.indexOf('\nfunction mergeMovedKey(', keyStart);
assert(normStart >= 0 && normEnd > normStart && easingStart >= 0 && easingEnd > easingStart && keyEnd > keyStart, 'animation functions should be extractable for behavioral tests');
const context = vm.createContext({ DURATION: 20, Math, Number, Object, Array, Map });
vm.runInContext(html.slice(normStart, normEnd) + '\n' + html.slice(easingStart, easingEnd) + '\n' + html.slice(keyStart, keyEnd), context);
const { normalizeKey, state, keyIndexAt, ensureEditableKey, updateKeyFromProp } = context;
const curve = { x1: 0, y1: 0, x2: 1, y2: 1 };
const item = { x: 0, y: 0, z: 0, s: 1, r: 0, o: 1, shake: 0, keys: [
  normalizeKey({ t: 0, x: 0, y: 0, z: -20, s: 1, r: 0, o: 1, shake: 0, curve }),
  normalizeKey({ t: 2, x: 100, y: -40, z: 40, s: 2, r: 90, o: .5, shake: 10, curve })
] };
const mid = state(item, 1);
assert.ok(Math.abs(mid.x - 50) < .02, 'X interpolates with time');
assert.ok(Math.abs(mid.y + 20) < .02, 'Y interpolates with time');
assert.ok(Math.abs(mid.z - 10) < .02, 'Z interpolates with time');
assert.ok(Math.abs(mid.s - 1.5) < .02, 'scale interpolates with time');
assert.ok(Math.abs(mid.r - 45) < .02, 'rotation interpolates with time');
assert.ok(Math.abs(mid.o - .75) < .02, 'opacity interpolates with time');
const index = ensureEditableKey(item, 1);
updateKeyFromProp(item, index, 'z', 25);
assert.equal(item.keys[index].z, 25, 'numeric Z edits current keyframe');
assert.ok(Math.abs(state(item, 1).z - 25) < .02, 'edited Z is reflected at the current playhead');
assert.ok(state(item, .5).z < 25 && state(item, 1.5).z !== 25, 'Z interpolates before and after the edited key');
const oldKey = normalizeKey({ t: 3, x: 2, y: 3, s: 1, r: 0, o: 1, shake: 0 });
assert.equal(oldKey.z, 0, 'legacy keyframes without Z migrate safely');
console.log('PASS MYRIX 2.2.0 animated transform keyframes: X/Y/Z/scale/rotation/opacity interpolate by timeline time');
