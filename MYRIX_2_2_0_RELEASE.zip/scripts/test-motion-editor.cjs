#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');

// Structural regressions for the timeline ruler and touch behavior.
assert.match(html, /const PX_PER_SEC=82, TRACK_H=38, LABEL_W=78, RULER_H=26/);
assert.match(html, /className='timelineRuler'/);
assert.match(html, /className='secondTick/);
assert.match(html, /className='secondGridLine/);
assert.match(html, /stage\.clientWidth\*canvasZoom/);
assert.match(html, /stage\.clientHeight\*canvasZoom/);
assert.match(html, /if\(panMode\|\|isPinchStart\)ev\.stopPropagation\(\)/);
assert.match(html, /const scroller=\$\('timelineScroller'\)/);
assert.match(html, /const threshold=width\*\.92/);
assert.match(html, /x-width\*\.75/);
assert.match(html, /playbackBaseTime\+Math\.max\(0,\(ts-playbackStartTs\)\/1000\)/);

// Exercise the real preset function outside the full DOM app.
const a = html.indexOf('function preset(t){');
const b = html.indexOf('\nfunction dragKey(', a);
assert.ok(a >= 0 && b > a, 'preset function must exist');
const presetSource = html.slice(a, b);
const selected = {
  id: 1, type: 'image', x: 5, y: -3, s: 1, r: 0, o: 1, shake: 0,
  keys: [
    {t:0,x:0,y:0,s:1,r:0,o:1,shake:0,curve:{x1:.333,y1:0,x2:.667,y2:1}},
    {t:5,x:10,y:4,s:1.2,r:15,o:1,shake:0,curve:{x1:.333,y1:0,x2:.667,y2:1}}
  ]
};
const state = {
  selected, time: 2, DURATION: 10, curveKeyIndex: -1,
  toastMessages: [], updates: 0, autosaves: 0, renders: 0,
  normalizeKey(k) {
    const c=k.curve||{x1:.333,y1:0,x2:.667,y2:1};
    return {t:Number(k.t)||0,x:Number(k.x)||0,y:Number(k.y)||0,s:Number(k.s)||1,r:Number(k.r)||0,o:Number.isFinite(+k.o)?+k.o:1,shake:Number(k.shake)||0,curve:c};
  },
  normalizeKeyList(keys) { const m=new Map(); keys.map(state.normalizeKey).forEach(k=>m.set(k.t.toFixed(3),k)); return [...m.values()].sort((x,y)=>x.t-y.t); },
  keyIndexAt(d,t) { return d.keys.findIndex(k=>Math.abs(k.t-t)<.005); },
  state(d,t) { const before=d.keys.filter(k=>k.t<=t).sort((x,y)=>y.t-x.t)[0]; return before?{...before}:{x:d.x,y:d.y,s:d.s,r:d.r,o:d.o,shake:d.shake}; },
};
const context = vm.createContext({
  selected, time: state.time,
  get DURATION(){return state.DURATION}, set DURATION(v){state.DURATION=v},
  get curveKeyIndex(){return state.curveKeyIndex}, set curveKeyIndex(v){state.curveKeyIndex=v},
  state:(d,t)=>state.state(d,t), normalizeKey:k=>state.normalizeKey(k),
  normalizeKeyList:keys=>state.normalizeKeyList(keys), keyIndexAt:(d,t)=>state.keyIndexAt(d,t),
  save(){}, renderTimeline(){state.renders++}, render(){state.renders++}, scheduleAutoSave(){state.autosaves++},
  updateTimelineDurationUI(){state.updates++}, toast(m){state.toastMessages.push(m)},
  $(){return {classList:{contains(){return false}}}}, Math, Number, Object, Array, Map, String,
});
vm.runInContext(presetSource, context, {timeout:1000});
context.preset('zoom');
assert.ok(selected.keys.some(k=>Math.abs(k.t-2)<.001), 'zoom preset should start on the current playhead');
assert.ok(selected.keys.some(k=>Math.abs(k.t-2.18)<.001 && k.s>1.1), 'zoom should grow in size after starting');
assert.ok(selected.keys.some(k=>Math.abs(k.t-2.82)<.001 && Math.abs(k.s-1)<.001), 'zoom should return to base scale');
assert.ok(selected.keys.some(k=>k.t===0) && selected.keys.some(k=>k.t===5), 'keys outside preset range must be preserved');
assert.ok(state.renders>=2 && state.autosaves===1, 'preset should render and autosave');

// Test all presets for sane time and transform values at a non-zero playhead.
for (const name of ['shake','zoom','bounce','flash','tile','wobble','swing','combo']) {
  context.time = 3; // sets VM global used by preset()
  context.preset(name);
  assert.ok(selected.keys.every(k=>Number.isFinite(k.t)&&k.t>=0&&k.t<=3600), name+' has invalid time');
  assert.ok(selected.keys.every(k=>Number.isFinite(k.s)&&k.s>=.2&&k.s<=3), name+' has invalid scale');
  assert.ok(selected.keys.every(k=>Number.isFinite(k.x)&&Number.isFinite(k.y)&&Number.isFinite(k.r)&&Number.isFinite(k.o)&&Number.isFinite(k.shake)), name+' has invalid transform');
}
console.log('PASS: timeline ruler has second ticks and per-layer grid');
console.log('PASS: canvas drag math compensates for zoom and hand mode does not drag underlying media');
console.log('PASS: playback playhead auto-follows horizontal timeline');
console.log('PASS: animation presets start at playhead, preserve surrounding keyframes, and stay within safe transform bounds');
