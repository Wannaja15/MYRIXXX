# MYRIX 2.2.0 — Editor Upgrade

MYRIX is a mobile-first HTML/JavaScript video editor packaged as an Android WebView application. This update is based on the existing 2.1.6 project and retains the current logo and dark teal/blue/yellow color palette.

## What changed in 2.2.0
- Fixed APK downloads by adding the `JJAndroid` WebView bridge. Video saving uses Android MediaStore for `Movies/MYRIX` and `Download/MYRIX`; Android versions below API 29 use the legacy public folders after storage permission is granted.
- Added a Null Object controller layer and parent linking for object transforms.
- Added a manual keyframe workflow with an explicit add-keyframe action and a delete-current-keyframe action. Editing animated properties at a time with no keyframe no longer silently creates one.
- Added Color Fill solid/linear/radial modes, second color, angle, opacity, and presets.
- Added editable Border & Shadow, blending modes, clip speed (0.25×–4×), and 3D-style tilt/card/depth presets.
- Kept extracted audio as a separate timeline layer and hide its layer object from the central preview canvas.
- Modernized the outer UI without changing the existing main palette or logo artwork; added a hamburger menu and local app settings.
- Project schema, autosave/restore, preview, export render, and tests have been updated for the new fields.

## Canonical files
- Standalone source for Acode: `MYRIX_2_2_0_RELEASE.html`
- Android WebView asset: `app/src/main/assets/index.html` (must remain byte-identical to the standalone HTML)
- Android project and old logo resources: `app/src/main/` and `app/build.gradle`
- GitHub Actions build: `.github/workflows/build-apk.yml`

## Build APK from a phone
1. Upload/commit the new `.github/workflows/build-apk.yml` to your repository at `.github/workflows/build-apk.yml`.
2. Upload `MYRIX_2_2_0_RELEASE.zip` to the repository root. The workflow deliberately chooses this ZIP before any older Android project source already present in the repository.
3. Open **GitHub → Actions → MYRIX 2.2.0 - Full Audit Build** and run it (or push a commit to `main`/`master`).
4. When the run is green, download artifact `MYRIX-2.2.0-debug-APK`. It includes the APK and a SHA-256 checksum.

The release ZIP is source code, not an already-built APK. The APK still needs to be produced by the GitHub Actions workflow and tested on the target phone.

## Verification status for this package
- `scripts/validate-project.py` passes: 237 unique HTML IDs, three inline JavaScript blocks parse, local links and Android XML/icon resources validate, and standalone/package HTML match exactly.
- All 16 `scripts/test*.cjs` checks pass, including `test-feature-suite-v220.cjs` for new features and Android save bridge.
- Workflow YAML/shell blocks are checked separately in the release audit.
- This environment did not have Gradle or an Android SDK installed, so it could not compile the APK locally. Static and Node tests are not a substitute for installing and testing the APK on a real Android device.
