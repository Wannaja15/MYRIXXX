#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(__dirname, '..', 'app', 'build.gradle'), 'utf8');

assert.match(html, /application-version" content="2\.1\.4/);
assert.match(html, /v2\.1/);
assert.match(gradle, /versionCode\s+12/);
assert.match(gradle, /versionName\s+'2\.1\.4'/);
assert.match(html, /id="photoCropTools"/);
assert.match(html, /id="cropOverlay"/);
assert.match(html, /id="cropModeBtn"/);
assert.match(html, /data-crop-edge="tl"/);
assert.match(html, /function cropEdgeDown\(ev\)/);
assert.match(html, /function cropEdgeMove\(ev\)/);
assert.match(html, /function cropFrameDown\(ev\)/, 'crop selection interior should be draggable');
assert.match(html, /data-crop-drag=\"move\"/, 'crop frame must include a movable interior');
assert.match(html, /max=\"95\" step=\"1\" value=\"0\" oninput=\"updateCropBoundary/, 'manual crop controls should allow deeper crop');
assert.match(html, /window\.toggleCropMode=toggleCropMode/);
for (const ratio of ['original','1:1','4:5','9:16','16:9','4:3']) {
  assert.ok(html.includes(`cropSelectedPhoto('${ratio}')`), `crop preset ${ratio} missing`);
}
for (const id of ['cropLeft','cropRight','cropTop','cropBottom']) assert.ok(html.includes(`id="${id}"`), `manual crop slider ${id} missing`);
assert.match(html, /window\.cropSelectedPhoto=cropSelectedPhoto/);
assert.match(html, /window\.updateCropBoundary=updateCropBoundary/);
assert.match(html, /crop:normalizeCrop\(x\.crop\)/, 'crop must be restored from project data');
assert.match(html, /crop:normalizeCrop\(d\.crop\)/, 'crop must be saved into project data');
assert.match(html, /if\(d\.type==='image'\|\|d\.type==='video'\)applyPhotoCrop\(d\)/, 'crop should be applied to photo and video preview');
assert.match(html, /drawCtx\.drawImage\(el,sx,sy,sw,sh,dx,dy,dw,dh\)/, 'crop should be applied during export');
assert.match(html, /const crop=normalizeCrop\(d\.crop\),nw=el\.videoWidth\|\|el\.width/, 'video crop source rect must be applied during export');
assert.match(html, /canCrop=!!d&&\['image','video'\]\.includes\(d\.type\)/, 'crop UI should be available for video and photo');
assert.match(html, /onclick="setSelectedStartAtPlayhead\(\)"/);
assert.match(html, /onclick="setSelectedEndAtPlayhead\(\)"/);
assert.match(html, /onclick="splitSelectedAtPlayhead\(\)"/);

const cropStart = html.indexOf('function normalizeCrop(value){');
const cropEnd = html.indexOf('\nfunction normalizeItem(', cropStart);
assert.ok(cropStart >= 0 && cropEnd > cropStart, 'crop helpers missing');
const block = html.slice(cropStart, cropEnd);
const metrics = {saved:0,autosaved:0,rendered:0,timeline:0,began:0,finished:0};
const controls = new Map();
for (const id of ['cropLeft','cropRight','cropTop','cropBottom','cropLeftValue','cropRightValue','cropTopValue','cropBottomValue','photoCropStatus']) controls.set(id, {value:'0',textContent:''});
const $ = id => controls.get(id) || null;
const ctx = vm.createContext({
  Math, Number, Object, JSON,
  selected:null, DURATION:60, time:0,
  clampNumber:(v,min,max,def)=>{const n=Number(v);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):def},
  $,
  save(){metrics.saved++},
  scheduleAutoSave(){metrics.autosaved++},
  applyPhotoCrop(d){d.crop=this.normalizeCrop(d.crop);d.el.style.clipPath='crop-applied'},
  render(){metrics.rendered++},renderTimeline(){metrics.timeline++},
  syncCropControls(d){for(const [key,id] of [['l','cropLeft'],['r','cropRight'],['t','cropTop'],['b','cropBottom']]){$(id).value=String(Math.round((d?.crop?.[key]||0)*100));$(id+'Value').textContent=$(id).value+'%'}},
  toast(m){metrics.lastToast=m},
  beginEdit(){metrics.began++},finishEdit(){metrics.finished++},
});
vm.runInContext(block + '\nthis.normalizeCrop=normalizeCrop;this.cropSelectedPhoto=cropSelectedPhoto;this.updateCropBoundary=updateCropBoundary;', ctx, {timeout:1000});
const photo={type:'image',el:{naturalWidth:1600,naturalHeight:900,style:{}},crop:{l:0,t:0,r:0,b:0}};
ctx.selected=photo;ctx.cropSelectedPhoto('1:1');
assert.ok(Math.abs(photo.crop.l-.21875)<.001 && Math.abs(photo.crop.r-.21875)<.001, 'square crop should trim equal sides on 16:9 photo');
ctx.cropSelectedPhoto('9:16');
assert.ok(photo.crop.l>.3 && photo.crop.r>.3 && photo.crop.t===0, 'portrait crop should trim width of a landscape photo');
ctx.updateCropBoundary('t', 18);
assert.ok(Math.abs(photo.crop.t-.18)<.001, 'manual crop slider should update selected photo crop');
assert.match(photo.el.style.clipPath, /^inset\(/, 'crop update should run preview application');
ctx.cropSelectedPhoto('original');
assert.deepEqual(JSON.parse(JSON.stringify(photo.crop)), {l:0,t:0,r:0,b:0}, 'reset should remove all crop margins');
const video={type:'video',el:{videoWidth:1920,videoHeight:1080,style:{}},crop:{l:0,t:0,r:0,b:0}};
ctx.selected=video;ctx.cropSelectedPhoto('9:16');
assert.ok(video.crop.l>.3 && video.crop.r>.3, 'portrait crop should work on landscape video');
ctx.updateCropBoundary('b', 12);
assert.ok(Math.abs(video.crop.b-.12)<.001, 'manual crop slider should update video crop');
assert.ok(metrics.saved>=4 && metrics.autosaved>=4 && metrics.rendered>=4 && metrics.began>=2 && metrics.finished>=2, 'crop edits should save, redraw, and schedule autosave');
const clamped=ctx.normalizeCrop({l:.9,r:.9,t:-1,b:.1});
assert.ok(clamped.l>=0 && clamped.r>=0 && clamped.l+clamped.r<=.951 && clamped.t>=0);

// Exercise the interactive crop box movement path, not just its markup.
const moveStart = html.indexOf('function cropEdgeMove(ev){');
const moveEnd = html.indexOf('function cropEdgeUp(ev)', moveStart);
assert.ok(moveStart >= 0 && moveEnd > moveStart, 'crop drag handler missing');
const moveCtx = vm.createContext({
  Math, Number,
  cropDrag: null,
  normalizeCrop: ctx.normalizeCrop,
  applyPhotoCrop(d) { d.crop = ctx.normalizeCrop(d.crop); d.el.style.clipPath = 'crop-applied'; },
  syncCropControls() {}, updateCropOverlay() {},
});
vm.runInContext(html.slice(moveStart, moveEnd) + '\nthis.cropEdgeMove=cropEdgeMove;', moveCtx, {timeout:1000});
const movable = {crop:{l:.2,t:.15,r:.3,b:.25},el:{style:{}}};
const before = {...movable.crop};
moveCtx.cropDrag = {id:9,edge:'move',startX:100,startY:100,rect:{width:200,height:100},crop:{...before},d:movable};
moveCtx.cropEdgeMove({pointerId:9,clientX:120,clientY:110,preventDefault(){}});
assert.ok(Math.abs(movable.crop.l-.3)<.001 && Math.abs(movable.crop.r-.2)<.001, 'moving crop box horizontally should preserve crop width');
assert.ok(Math.abs(movable.crop.t-.25)<.001 && Math.abs(movable.crop.b-.15)<.001, 'moving crop box vertically should preserve crop height');
assert.ok(Math.abs((movable.crop.l+movable.crop.r)-(before.l+before.r))<.001, 'move gesture must not resize crop width');
assert.ok(Math.abs((movable.crop.t+movable.crop.b)-(before.t+before.b))<.001, 'move gesture must not resize crop height');
console.log('PASS: version 2.1.4 and Android versionCode 12 are set');
console.log('PASS: photo/video ratio crop and manual crop sliders update the selected media');
console.log('PASS: preview, export source-crop, project persistence and autosave hooks are connected');
console.log('PASS: video trim start/end/split controls remain present');
console.log('PASS: crop values are normalized and clamped');
console.log('PASS: crop frame interior moves the selection without resizing it');
