const fs=require('fs');const assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const fn=html.match(/function splitSelectedAtPlayhead\(\)\{[\s\S]*?\n\}/);
assert(fn,'split function exists');
for(const token of ['itemTimelineStart(d)','itemTimelineEnd(d)','_timelineStart:splitAt,_timelineEnd:end','d._timelineEnd=splitAt','d.trimOut=sourceCut','nd.trimIn=sourceCut','select(nd)','scheduleAutoSave()']) assert(fn[0].includes(token),'split function missing '+token);
assert(html.includes('id="splitTimelineBtn"'),'persistent CUT button exists');
assert(html.includes("ev.key.toLowerCase()!=='s'"),'S shortcut exists');
assert(html.includes('v2.1'),'UI version badge upgraded');
assert(html.includes('MYRIX 2.1.4 — Time-Synced Transform'),'document title upgraded');
// Time-boundary model checks for exact split invariants: [start, cut] + [cut, end].
for(const [start,cut,end] of [[0,1.5,5],[2,3.25,8],[0.25,0.5,1]]){
 assert(cut>start && cut<end);assert.strictEqual((cut-start)+(end-cut),end-start);
}
console.log('PASS MYRIX split-layer structure, timeline button, shortcut, version, and segment-boundary invariants');
