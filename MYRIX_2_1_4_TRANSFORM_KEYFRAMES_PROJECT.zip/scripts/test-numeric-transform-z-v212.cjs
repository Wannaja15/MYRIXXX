const fs=require('fs');const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const ids=['pxn','pyn','pzn','scn','rtn','opn','shn'];
for(const id of ids) if(!new RegExp('id="'+id+'"[^>]*type="number"|id="'+id+'"[^>]*class="valueInput"').test(html)) throw new Error('Missing numeric input '+id);
if(!html.includes("num.addEventListener('change'")) throw new Error('Numeric input change handler missing');
if(!html.includes('1000000+(depth*10000)')) throw new Error('Global Z depth formula missing');
if(!html.includes("sort((a,b)=>((Number(state(a.d,t).z)||0)-(Number(state(b.d,t).z)||0))")) throw new Error('Export keyframed Z sorting missing');
if(!html.includes('z:num(k.z,0,-100,100)')) throw new Error('Z keyframe normalization missing');
if(!html.includes("else if(p==='z')k.z=Math.max(-100,Math.min(100,n))")) throw new Error('Z keyframe editing missing');
console.log('PASS MYRIX numeric transform and Z depth hooks remain present and animate in 2.1.4');
