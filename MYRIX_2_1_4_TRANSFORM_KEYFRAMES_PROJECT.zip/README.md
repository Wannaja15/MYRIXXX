# MYRIX 2.1.4 — Time-Synced Transform

Update ini membuat gerakan transform layer tersinkron dengan waktu timeline.

## Fitur utama
- Keyframe animasi X, Y, Z/depth, skala, rotasi, opacity, dan shake.
- Panel transform menampilkan nilai yang sedang berlaku di posisi playhead.
- Urutan tumpukan Z mengikuti animasi di pratinjau dan ekspor.
- Migrasi keyframe lama tetap mempertahankan Z statis layer.
- Workflow GitHub Actions menjalankan tes fitur lalu membangun debug APK.

## Workflow APK
File workflow berada di `.github/workflows/build-apk.yml`. Jalankan lewat GitHub Actions atau push ke `main`/`master`. APK tersedia sebagai artifact `MYRIX-2.1.4-debug-APK` jika build berhasil.

## Membuat gerakan
1. Pilih layer di timeline.
2. Pindahkan playhead ke waktu awal dan atur X/Y/Z, skala, dan rotasi.
3. Tekan **Keyframe**.
4. Geser playhead ke waktu berikutnya dan ubah satu atau lebih nilai transform. Saat keyframe sudah ada, pengubahan nilai pada waktu baru akan membuat keyframe di waktu itu.
5. Putar untuk melihat transform bergerak di antara keyframe.

Catatan: tes otomatis bukan pengganti pengujian pada perangkat Android. Build nyata harus dikonfirmasi pada GitHub Actions.
