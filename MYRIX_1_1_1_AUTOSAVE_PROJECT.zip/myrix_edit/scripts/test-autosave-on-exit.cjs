const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/myrix/editor/MainActivity.java'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');
function check(ok, message) { if (!ok) { console.error('FAIL:', message); process.exitCode = 1; } else console.log('PASS:', message); }
check(html.includes("AUTO_RESUME_KEY='myrix-auto-resume-after-exit-v1'"), 'resume flag exists');
check(/setTimeout\(\(\)=>writeAutoSaveDraft\(\),500\)/.test(html), 'short debounced autosave is active after edits');
check(html.includes('window.MYRIX_SAVE_ON_EXIT=async function()'), 'async final-save handler exists');
check(html.includes("window.addEventListener('pagehide'"), 'pagehide performs final save');
check(html.includes("document.addEventListener('visibilitychange'"), 'background lifecycle performs final save');
check(html.includes('maybeResumeDraftAfterUnexpectedExit();'), 'latest draft can auto-resume after unexpected exit');
check(java.includes('window.MYRIX_SAVE_ON_EXIT'), 'Android requests save when paused/back is pressed');
check(java.includes('pollExitSaveAndFinish'), 'Android waits for final-save completion before closing');
check(/versionCode 3/.test(gradle) && /versionName '1\.1\.1'/.test(gradle), 'Android version is 1.1.1 / code 3');
if (process.exitCode) process.exit(process.exitCode);
